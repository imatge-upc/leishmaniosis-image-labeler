
est_time = 120*1*1.1578e-05+now;
waitSTR = sprintf('Image:  1 of 10 \nExpected Time to End: %s',datestr(est_time))
h = waitbar(0.1,waitSTR);
pause(1)