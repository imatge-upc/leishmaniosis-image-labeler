function single = cropWell(I,center,R,rthick,marg,border,black) %#ok<*INUSL>

% ------------------------------------------------------------------------
% function single = cropWell(I,center,R,rthick,border,marg,black) execute
% the crop around a well shape according to input parameters.
%
%   Output: - single: single well cropped image (matrix nXn)
%
%   Input:  - I: original image (matrix mXk)
%           - center: center coordiantes (vector 1X2)
%           - R: radius of the well (scalar)
%           - rthick: ring thickness (scalar)
%           - marg (facultative): margin around the well (scalar)
%           - border (facultative): addictional band (scalar, defauls 0)
%           - black (facultative): black crow around well 
%                                   0 (default): no ring
%                                   1: black crow
%
% V. 1.0 - A. Negro, LSCB, EPFL, July 2011
% lscb.epfl.com
% ------------------------------------------------------------------------

%% Preliminary
if nargin < 7
    black = 0;
end
if nargin < 6
    border = 0;
end
if nargin < 5
    marg = 0;
end
R = R+marg;
single = [];
% Video->pic conversion: produce an average of the video
if iscell(I)
    Iavg = I{1}/length(I);
    for i = 2 : length(I)
        Iavg = Iavg + I{i}/length(I);
    end
else
    Iavg = I;
end
Iavg = double(Iavg);

%% Pre-processing
% Adding a blank border: safe cropping
[d1 d2] = size(Iavg);
gap = round(R*2);
I2 = (zeros(d1+2*gap,d2+2*gap));
I2(gap+1:gap+d1, gap+1:gap+d2) = Iavg;
center = center(1,1:2) + gap; % center is moved as well
% Mask generation
mask = createCircleImage(R,rthick); 
[r,c] = size(mask);
mask2 = zeros(r+2*border,c+2*border);
mask2(border+1:r+border,border+1:c+border) = mask;
mask = mask2;
[r,c] = size(mask);
for i = 1 : r;
    start = find(mask(i,:)>0,1,'first');
    mask(i,start:c-start+1) = max(mask(:));
end
if black
    mask(mask>0) = 1; %#ok<*NASGU>
else
    mask(:) = 1;
end

%% Cropping
% Limit of cropping
a = center(2)+fix(c/2);
b = center(2)-fix(c/2);
d = center(1)+fix(r/2);
e = center(1)-fix(r/2);
% Selection
if iscell(I)
    for i = 1 : length(I)
        I2(gap+1:gap+d1, gap+1:gap+d2) = I{i};
        single{i} = uint16(immultiply(I2(b:a,e:d),mask)); %#ok<*AGROW>
    end
else
    I2(gap+1:gap+d1, gap+1:gap+d2) = I;
    single = uint16(immultiply(I2(b:a,e:d),mask));
end

