function centers = HOUGHdetect(I, r, rthick, quality, flt2do)

% ------------------------------------------------------------------------
% function centers = HOUGHdetect(I, r, rthick, quality, flt2do) performs
% well detection based on circular hough transform. 
%
%   Output: - centers: well center coordinates (matrix nX2)
%
%   Input:  - I: image (matrix nXm)
%           - r: well radius (scalar)
%           - rthick (facultative): ring thickness (scalar, default 2)
%           - quality (facultative): index of image quality (scalar 0:1, 
%                                       default 0.5)
%           - flt2do (facultative): filtering method choice
%                       0 (default): no preliminary filtering
%                       1: filtering (BG correction, median and threshold)
%
% V. 1.0 - A. Negro, LSCB, EPFL, July 2011
% lscb.epfl.com
% ------------------------------------------------------------------------

%% Preliminary actions
% Input check and correction
if nargin < 5
    flt2do = 0;
end
if nargin < 4 
    quality = 0.5;
end
if nargin < 3
    rthick = 2;
end
% Pre-assign output
centers = []; %#ok<*NASGU>
% Radius range
radrange = [r-round(rthick/2), r+round(rthick/2)];
% Video->pic conversion: produce an average of the video
if iscell(I)
    Iavg = I{1}/length(I);
    for i = 2 : length(I)
        Iavg = Iavg + I{i}/length(I);
    end
    I = Iavg;
end

%% Optional filtering
if flt2do
    % 1- Background correction
    hsize = 25;
    sigma = 10;
    n = 7;
    I = bgCorrection(I,hsize,sigma,n);

    % 2- Median and Gaussian Filtering
    I = medfilt2(I);
    G = fspecial('gaussian',5,2);
    I = imfilter(I,G);

    % 3- Invert Image
    I = imcomplement(I);
    I = adapthisteq(I);
end

%% Circular Hough Detection
grdthresh = 10; % default, NON negative
fltr4LM_R = 8; % default, filter for local maxima, min=3
[~, circen, cirrad] = CircularHough_Grd(I, radrange, grdthresh,fltr4LM_R,quality);
circen = round(circen);
centers = [circen,cirrad-r];
Ncent = length(cirrad);

%% Screening for double centers: selection on radius
MATR = zeros(Ncent);
for i = 1 : Ncent
    for j = i+1 : Ncent
        MATR(i,j) = sqrt((centers(i,1)-centers(j,1))^2 + (centers(i,2)-centers(j,2))^2);
    end
end
MATR = round(MATR);
for i = 1 : Ncent
    for j = i+1 : Ncent
        if MATR(i,j)<r;
            centers(j,3)=inf;
        end
    end
end
centers = centers(~isinf(centers(:,3)),1:2);