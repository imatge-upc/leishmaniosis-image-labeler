function [centersout,geometry] = well_screen(centers,r)

% ------------------------------------------------------------------------
% function [centersout,geometry] = well_screen(centers,r) sort and
% investigate the well array.
%
%   Output: - centersout: sorted well coordinates x,y (matrix nX2)
%           - geometry: rows and columns of the arary (matrix 2X1)
%
%   Input:  - centers: detected well coordinates x,y (matrix nX2)
%           - r: well radius in pixel (scalar)
%
% V. 1.0 - A. Negro, LSCB, EPFL, July 2011
% lscb.epfl.com
% ------------------------------------------------------------------------

%% Preparation
xc = centers(:,1);
yc = centers(:,2);
n_cent = length(xc);
% Quick exit: 1 or 0 well
if n_cent == 0
    centersout = [];
    geometry = [0 0];
    return;
end
if n_cent == 1
    centersout = centers;
    geometry = [1 1];
    return;
end

%% Define a reference well
xTL = min(centers(:,1));
index = centers(:,1)==xTL;
yTL = centers(index,2); 
index1 = centers(:,1) < xTL + r & centers(:,1) > xTL-r;
ytest = centers(index1, 2);
ytest = sort(ytest);
index2 = find(centers(:,2)==ytest(1),1);
yTL = ytest(1);
xTL = centers(index2,1);

%% Geometry Evaluation and Sorting
% Starting from origin to right
xx = xTL;
yy = yTL;
xmin = xx + 2*r;
xmax = xx + 5*r;
ymin = yy - r;
ymax = yy + r;
[xout1 yout1] = findObjectBetweenLimits(xc,yc,xmin,xmax,ymin,ymax); %#ok<*NASGU>
% Check: is there a right neighbour?
if ~isempty(xout1)  && (length(xout1) == 1)
    % Investigation of the geometry left to right
    flag = 1;
    i = 1;
    xx =  xTL;
    yy = yTL;
    centersout(1,:)=[xTL, yTL];
    while flag && (i<n_cent)     
        % Check the neighbourhood 
        xmin = xx + 2*r;
        xmax = xx + 5*r;
        ymin = yy - r;
        ymax = yy + r;
        [xout3 yout3] = findObjectBetweenLimits(xc,yc,xmin,xmax,ymin,ymax);
        % Empty neighbourhood: out of the cicle
        if isempty(xout3)
            flag = 0;
        else
            %I changed this because when the gel is broken, the wells are
            %not aligned and then the centers are not ordered. But the
            %findObjectBetweenLimits function will find them well.
            xx = xout3(1);
            yy = yout3(1);
            i = i + 1;
            % First row of well already sorted
            centersout(i,:) = [xx, yy];
        end
    end
    % i, at the end of cycle, represents the number of columns of the array
    colW = i;
    rowW = n_cent / i; 
    % If the number of columns/rows is equal to 0 or isn't integer: non possible detection 
    if (rowW~=round(rowW)) || (colW~=round(colW)) || (rowW==0) || (colW==0) 
        geometry = [0 0];
        centersout = [];
        return
    else
        geometry = [rowW, colW];
    end
    % Sorting
    for j=0:1:(rowW-2)  % Repeated for all rows
        % Selectio of the element of the last sorted row
        xx = centersout(j*colW+1,1);
        yy = centersout(j*colW+1,2);
        xmin = xx - r;
        xmax = xx + r;
        ymin = yy + 2*r;
        ymax = yy + 5*r;
        [xout3 yout3] = findObjectBetweenLimits(xc,yc,xmin,xmax,ymin,ymax);
        % No neighbours and no last row: out of the script
        if (isempty(xout3)) && (j~=rowW-2)
            geometry = [0 0];
            centersout = [];
            return
        end
        % A present well: continue to sort
        if (~isempty(xout3))
            centersout((j+1)*colW+1,:)=[xout3 yout3];
            xx = xout3;
            yy = yout3;
            flag = 1;
            i =0;
            while flag
                % Continue to fill the row
                xmin = xx + 2*r;
                xmax = xx + 5*r;
                ymin = yy - 1*r;
                ymax = yy + 1*r;
                [xout3 yout3] = findObjectBetweenLimits(xc,yc,xmin,xmax,ymin,ymax);
                if isempty(xout3)
                    flag = 0;
                else
                    i = i + 1;
                    xx = xout3;
                    yy = yout3;
                    centersout((j+1)*colW+1+i,:)=[xout3, yout3];
                end
            end
        end
    end
    
else
    % See line 42 - No right neighbour: no geometry
    geometry = [0 0];
    centersout = [];
    return
end

%% Further Control: no correpsondance of geometry and number of well
if size(centersout,1) ~= geometry(1)*geometry(2)
    geometry = [0 0];
    centersout = [];
end