% processing of the black-list only

function [] = Black_PRO()

close all;
clear all;
clc;

% For having a system-indipendent software
sep = '\';
if ismac
    sep = '/';
end
if ispc
    sep = '\';
end

[FileN,PathN] = uigetfile('*.mat','Select the Black-List file');
fileN = strcat(PathN,FileN);
load(fileN);

% Processing of the black list
for i = 2 : length(black_list)   
    % Select the file: no control, they've been done before
    currentFile = black_list{i}
    % Read tif stack
    I = ANtiffread(currentFile);
    if iscell(I)
    % Video: produce an average of the video
        Iavg = I{1}/length(I);
        for j = 2 : length(I)
            Iavg = Iavg + I{j}/length(I);
        end
    end

    % Manual well selection
    centers = selectWell(Iavg);
    [centers, geometry] = well_screen(centers,r);
    
    % Crop and save
    if ~isempty(centers)
        % Processing the image: chopping the single wells
        actual = 0;
        for row = 1:1:geometry(1)
            for col = 1:1:geometry(2)
                actual = actual+1;
                CC = cropWell(I,centers(actual,:),r,rthick,BLACK);
                instruction = strcat('crop_',num2str(row),num2str(col),' = CC;');
                eval(instruction);
            end
        end
    end
    thisMatVar = strcat(currentFile(1:length(currentFile)-4),'_MANUALCOUNT.mat');
    save(thisMatVar, 'crop_*', 'geometry', '-mat');
    clear crop*
end