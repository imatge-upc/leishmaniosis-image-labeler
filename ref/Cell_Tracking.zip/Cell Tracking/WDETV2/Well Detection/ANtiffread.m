function stackOK = ANtiffread(filename, indices)

% ------------------------------------------------------------------------
% function stackOK = ANtiffread(filename, indices) call and rearrange in
% cell arrays the video read by tiffread.m.
%
%   Output: - stackOK: video cell array (cell array nX1)
%
%   Input:  - filename: video file name (string)
%           - indices (facultative): frames to extract (vector of integer,
%                       nX1, default all frames).
%
% V. 1.0 - A. Negro, LSCB, EPFL, July 2011
% lscb.epfl.com
% ------------------------------------------------------------------------

%% Tiff Reading
if nargin < 2
    stack = tiffread(filename);
else
    stack = tiffread(filename, indices);
end
    
%% Output Re-Arrangement
stackOK = [];
if exist('stack','var')
    if (length(stack)-1) %#ok<*BDLOG>
        % only the field data, within the structure is interesting
        stackOK{1} = stack(1).data;
        for j = 2:1:length(stack)
            stackOK{j} = stack(j).data; %#ok<*AGROW>
        end
    else
        stackOK = stack(1).data;
    end
end