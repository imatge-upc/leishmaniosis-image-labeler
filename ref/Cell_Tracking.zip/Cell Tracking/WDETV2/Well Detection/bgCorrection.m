function Ibg = bgCorrection(I,hsize,sigma,n)

% ------------------------------------------------------------------------
% function Ibg = bgCorrection(I,hsize,sigma,n) corrects image background
% based on gausssian filtering.
%
%   Output: - Ibg: corrected image (matrix mXn)
%
%   Input:  - I: image to correct (matrix mXn)
%           - hsize: filter size (scalar)
%           - sigma: standard deviation of the gaussian (scalar)
%
% V. 1.0 - A. Negro, LSCB, EPFL, July 2011
% lscb.epfl.com
% ------------------------------------------------------------------------

%% Image encoding investigation
COD = whos('I');
COD = COD.class;

%% Background image generation
G = fspecial('gaussian',hsize,sigma);   
Ismooth = imfilter(I,G,'replicate');
if n > 1
    for i = 2:1:n
        Ismooth = imfilter(Ismooth,G,'replicate');
    end
end

%% Background correction
Ibg = double(I) ./ double(Ismooth);

%% Rescale image to 8bit or 16bit
if strfind('uint8',COD)
    Ibg = im2uint16(Ibg);
else
    Ibg = im2uint16(Ibg);
end
