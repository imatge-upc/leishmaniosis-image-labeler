function [] = prepare_HSC()

% ------------------------------------------------------------------------
% function prepare_HSC() prepares the single well crops for rpoliferation
% analysis. The function is investigating a mother folder in order to
% process tiff stack and produce video of single wells. Hough transform is
% used to detect the circular shape.
% Input operation are performed through GUI.
%
%   Instruction:
% 1- Select a mother folder containing all the .tif file to process
% 2- Input an approximation of well radius in pixel and, in case, change
%       the thickness to screen through multiple radius. No default is
%       present for the radius.
% 3- Software is processing showing a progression bar and the estimated
%       ending time. In case processing could not be accomplished properly,
%       the image name is stored a black lis file for manual processing by
%       'Black._PRO.m' in a second moment.
% 4- All the processed images will have at the end of the process, a twin
%       file _MANUALCOUNT.mat, while unprocessed images won't. The
%       workspaces are containing single cell arrays containing the video
%       for single wells and a geometry variable ([row, col]). Naming of
%       the video gives the position in the array.
% 5- In the images folder there will be also the file 'BLACK_LIST.mat'
%       containing the integral address to access the un-processed 
%       pictures.
%
% No input/output: direct writing of files
%
% V. 1.0 - A. Negro, LSCB, EPFL, July 2011
% lscb.epfl.com
% -----------------------------------------------------------------------

%% Preliminary
close all;
clear all;
clc;
% For having a system-indipendent software
sep = '\';
if ismac
    sep = '/';
end
if ispc
    sep = '\';
end

%% Inputs and Settings
% Select input directory
input_directory = uigetdir('C:\','Select INPUT directory. Warning: file names must contain no space!');
if (input_directory == 0)
    error('This directory does not exist');
end
clc
% Experiment parameters
prompt = {'Radius of the wells (pixels):','Thickness of the ring shape for wells detection (pixels)'};
dlg_title = 'Input for Parameters';
num_lines = 1;
def = {'','5',};
answer = inputdlg(prompt,dlg_title,num_lines,def);
% Processsing of inputs
r = str2double(answer{1});
rthick = str2double(answer{2});
if isempty(r)
    warning(2,'The radius of the wells is a necessary parameters and cannot be omitted.');
    return;
end
% Hidden Parameters
quality = 0.5;
BLACK = 0;
flt2do = 0; % Filtering of the images: 0 fast processing - 1 sower and more accurate
clc;

%% File Screening
% Loop throughout all the files in input directory
files = dir(input_directory);
BL_IND = 0;
n_file = length(files);
counter = 0;
for i = 1 : 1 : n_file
    name = char(files(i).name);
    % Removal of to short names ('.' and '..' in Windows)
    if length(name) > 3
        strin = char(name(length(name)-2:length(name)));
        % Removal of non-tiff files
        if strcmp(strin, 'tif') || strcmp(strin, 'TIF')
            counter = counter+1;
            files2(counter)=files(i);
        end
    end
end
files = files2;

%% Operative Cycle
n_file = length(files);
for i = 1:1:n_file
    %% Reading and Display
    % File
    name = char(files(i).name);
    disp(name) % Display of the file in processing
    currentFile = strcat(input_directory, sep, files(i).name);
    % Progression display
    if exist('sing_time','var')
        % When a first time was already evaluated
        close(h)
        est_time = (n_file-i)*sing_time*1.1578e-05+now;
        waitSTR = sprintf('Image:  %d of %d \n Expected Time to End: %s',i,n_file,datestr(est_time));
        h = waitbar(i/n_file,waitSTR);
    else
        % First image
        waitSTR = sprintf('Image:  1 of %d \n Expected Time to End: Unknown yet',n_file);
        h  = waitbar(1/n_file,waitSTR);        
    end
    tic % Timer of the actual video processing
    
    %% Processing
    % Read tif stack
    stack = ANtiffread(currentFile); 
    % Detect the wells on the MIP image
    centers = HOUGHdetect(stack,r,rthick,quality,flt2do); 
    % Screen and sort the wells
    [centers, geometry] = well_screen(centers,r);
    %% Check the detection
    if isempty(centers)
        % No proper well-screening: update the black-list
        warning(strcat('It was not possible to determine the grid geometry for image - ',name));
        BL_IND = BL_IND+1;
        black_list{BL_IND} = strcat(input_directory, sep, name); %#ok<*AGROW>
        BLACKFILE = strcat(input_directory, sep, 'BLACK_LIST.mat');
        save(BLACKFILE,'black_list','r','rthick','BLACK');
    else
        % Processing the image: cut the single well
        actual = 0;
        for row = 1:1:geometry(1)
            for col = 1:1:geometry(2)
                actual = actual+1;
                CC = cropWell(stack,centers(actual,:),r,rthick,0,BLACK); %#ok<*NASGU>
                instruction = strcat('crop_',num2str(row),num2str(col),' = CC;');
                eval(instruction);
            end
        end
        % Saving
        thisMatVar = strcat(currentFile(1:length(currentFile)-4),'_MANUALCOUNT.mat');
        save(thisMatVar, 'crop_*', 'geometry', '-mat');
        clear crop*
    end

    %% Elapsed time for the actual operation
    sing_timeT = toc;
    if exist('sing_time','var')
        sing_time = (sing_time+sing_timeT)/2;
    else
        sing_time = sing_timeT;
    end
end

%% Save the black-list
BLACKFILE = strcat(input_directory, sep, 'BLACK_LIST.mat');
save(BLACKFILE,'black_list','r','rthick','BLACK');

%% Final message about processing
close(h)
Message{1} = sprintf('Automatic Processing Complete: %d/%d',(n_file-length(black_list)),n_file);
Message{2} = sprintf('To process manually: %d',length(black_list));
Message{3} = sprintf('Type ''Black_PRO'' and press Enter.');
h = msgbox(Message,'Processing','warn');