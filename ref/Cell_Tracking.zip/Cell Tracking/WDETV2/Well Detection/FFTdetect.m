function center = FFTdetect(I,r,rthick,way) %#ok<*INUSD>

% ------------------------------------------------------------------------
% function center = FFTdetect(I,r,rthick,way) detetct a single well shape
% in a frame or video by FFT convolution with artificial well template.
%
%   Output: - center: center coordinates (matrix 1X2)
%
%   Input:  - I: image or video (matrix nXm or cell array {nXm}Xk)
%           - r: radius of the well in pixel (scalar)
%           - rthick: thickness of the ring in pixel (scalar)
%           - way: processing method
%                   1 (default): several correction: bg correction, median
%                       and border correction
%                   0: edge detection and dilation
%
% V. 1.0 - A. Negro, LSCB, EPFL, July 2011
% lscb.epfl.com
% ------------------------------------------------------------------------


%% Preliminary actions
% Check and correction of input
if nargin < 4, way = 1; end % 1=Old version 0=new version with edge 
if nargin < 3, rthick = 5; end
% Initialization of output
center = [];
% Video->pic conversion: produce an average of the video
if iscell(I)
    Iavg = I{1}/length(I);
    for i = 2 : length(I)
        Iavg = Iavg + I{i}/length(I);
    end
    I = Iavg;
end

%% Filtering 
if way
    % 1- Background correction (low-pass filtering)
    hsize = 25;
    sigma = 10;
    n = 7;
    Ic = bgCorrection(I,hsize,sigma,n);
    % 2- Median and Gaussian filtering
    Ic = medfilt2(Ic);
    G = fspecial('gaussian',5,2);
    Ic = imfilter(Ic,G);
    % 3- Invert image
    Ic = imcomplement(Ic);
    %4-  Border correction
    [hei wid] = size(Ic);
    Ic(1:hei*0.02,:) = min(Ic(:));
    Ic(0.98*hei:hei,:) = min(Ic(:));
    Ic(:,1:wid*0.02) = min(Ic(:));
    Ic(:,0.98*wid:wid) = min(Ic(:));
    % 5- Hard thresholding to separate circles area and background area
    B = sort(Ic(:), 'descend');
    n = round(length(B)*0.01);
    thresholdSup = 0.3 * mean(B(10:10+n))/double(intmax(class(I)));
    Ic = im2bw(Ic, thresholdSup); 
else
    [Ic,th] = edge(I,'canny');  % Edge detection
    Ic = edge(I,'canny',[th(1)*0.35 th(2)*2.6]);    % Canny edge detection with threshold correction 0.9^10 and 1.1^10
    Ic = imdilate(Ic,strel('disk',rthick));  % Mask dilation to better cover the area
end

%% Convolution
% Circular pattern
C = createCircleImage(r,rthick); 
% Zero-padding to the image
dim = round(size(C,1)/2);
Icpad = zeros(size(Ic,1)+2*dim,size(Ic,2)+2*dim);
Icpad(dim+1:dim+1+size(Ic,1)-1,dim+1:dim+1+size(Ic,2)-1) = Ic;
% Fourier Transforms: image and pattern
FIc = fft2(Icpad);
FC = fft2(C,size(Icpad,1),size(Icpad,2));
% Convolution
FIconv = FIc .* FC;
% Inverse Fourier Transform
Iconv = shift4FFT(ifft2(FIconv),dim);

%% Center Calculation
maxX = max(Iconv);
maxY = max(Iconv'); %#ok<*UDIM>
center(1) = find(maxX==max(maxX(:)),1,'first');
center(2) = find(maxY==max(maxY(:)),1,'first');
