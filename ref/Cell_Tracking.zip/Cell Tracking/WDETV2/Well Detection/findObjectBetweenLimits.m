function [xout yout] = findObjectBetweenLimits(xx,yy,xmin,xmax,ymin,ymax)

% ------------------------------------------------------------------------
% function [xout yout] = findObjectBetweenLimits(xx,yy,xmin,xmax,ymin,ymax)
% finds if some points are geometrically placed within defined ranges. 
%
%   Output: - xout: x coordiante of identified spots (matrix nX1)
%           - yout: y coordiante of identified spots (matrix nX1)
%
%   Input:  - xx: x coordinate population (matrix mX1)
%           - yy: y coordinate population (matrix mX1)
%           - xmin: minimum x coordinate (scalar)
%           - xmax: maximum x coordinate (scalar)
%           - ymin: minimum y coordinate (scalar)
%           - ymax: maximum y coordinate (scalar)
%
% V. 1.0 - A. Griffa, BIOP, EPFL, October 2009
% lscb.epfl.com
% ------------------------------------------------------------------------

xcv4 = [];
ycv4 = [];

if (~isempty(find(xx > xmin)));
    xcv1 = xx(find(xx > xmin));
    ycv1 = yy(find(xx > xmin));
    if ~isempty(find(xcv1 < xmax))
        xcv2 = xcv1(find(xcv1 < xmax));
        ycv2 = ycv1(find(xcv1 < xmax));
        if ~isempty(find(ycv2 < ymax))
            xcv3 = xcv2(find(ycv2 < ymax));
            ycv3 = ycv2(find(ycv2 < ymax));
            if ~isempty(find(ycv3 > ymin))
                xcv4 = xcv3(find(ycv3 > ymin));
                ycv4 = ycv3(find(ycv3 > ymin));
            end
        end
    end
end

if (isempty(xcv4))
    %disp('Warning in findObjectsBetweenLimits: empty output');
end

xout = xcv4;
yout = ycv4;
