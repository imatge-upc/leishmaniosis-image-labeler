function varargout = selectWell(varargin)
% SELECTWELL MATLAB code for selectWell.fig
%      SELECTWELL, by itself, creates a new SELECTWELL or raises the existing
%      singleton*.
%
%      H = SELECTWELL returns the handle to a new SELECTWELL or the handle to
%      the existing singleton*.
%
%      SELECTWELL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SELECTWELL.M with the given input arguments.
%
%      SELECTWELL('Property','Value',...) creates a new SELECTWELL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before selectWell_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to selectWell_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help selectWell

% Last Modified by GUIDE v2.5 20-Jun-2011 15:15:02

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @selectWell_OpeningFcn, ...
                   'gui_OutputFcn',  @selectWell_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before selectWell is made visible.
function selectWell_OpeningFcn(hObject, ~, handles, varargin)
handles.I = varargin{1};
imagesc(handles.I),axis equal, axis tight, colormap gray;
handles.output = [];
guidata(hObject, handles);
uiwait(handles.SelectWell);


% --- Outputs from this function are returned to the command line.
function varargout = selectWell_OutputFcn(~, ~, handles) 
varargout{1} = round(handles.output);
delete(handles.SelectWell);

% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
handles.output = [];
imagesc(handles.I),axis equal, axis tight, colormap gray;
[x,y,button] = ginput(1);
while button == 1
    hold on, plot(x,y,'*r'),hold off;
    handles.output = [handles.output;[x,y]];
    [x,y,button] = ginput(1);
end
guidata(hObject,handles);

% --- Executes when user attempts to close SelectWell.
function SelectWell_CloseRequestFcn(hObject, ~, ~) %#ok<*DEFNU>
if isequal(get(hObject, 'waitstatus'), 'waiting')
    % The GUI is still in UIWAIT, us UIRESUME
    uiresume(hObject);
else
    % The GUI is no longer waiting, just close it
    delete(hObject);
end
