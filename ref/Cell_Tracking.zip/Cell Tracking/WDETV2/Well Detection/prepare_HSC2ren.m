%
% This function prepare the gray levels cropped image for manual cell count
%

function [] = prepare_HSC()

close all;
clear all;
clc;

% For having a system-indipendent software
sep = '\';
if ismac
    sep = '/';
end
if ispc
    sep = '\';
end

% Select input directory
input_directory = uigetdir('C:\','Select INPUT directory. Warning: file names must contain no space!');
if (input_directory == 0)
    error('This directory does not exist');
end

% Input parameters
clc;

% black crown (1) or not (0)
BLACK = 0;

prompt = {'Radius of the wells (pixels):','Thickness of the ring shape for wells detection (pixels)','Quality of input image in term of noise, between 0 and 1'};
dlg_title = 'Input for Parameters';
num_lines = 1;
def = {'','5','0.5'};
answer = inputdlg(prompt,dlg_title,num_lines,def);

r = str2double(answer{1});
rthick = str2double(answer{2});
quality = str2double(answer{3});

% r = input('Radius of the wells (pixels): ');
if isempty(r)
    warning(2,'The radius of the wells is a necessary parameters and cannot be omitted.');
    return;
end

flt2do = 0; % Filtering of the images: 0 fast processing - 1 sower and more accurate
clc;

% Loop throughout all the files in input directory
files = dir(input_directory);
BL_IND = 0;
n_file = length(files);
counter = 0;
for i = 1 : 1 : n_file
    name = char(files(i).name);
    if length(name) > 3
        strin = char(name(length(name)-2:length(name)));
        if strcmp(strin, 'tif') || strcmp(strin, 'TIF')
            counter = counter+1;
            files2(counter)=files(i);
        end
    end
end
files = files2;
n_file = length(files);
for i = 1:1:n_file
    name = char(files(i).name);
    
    % Progression display
    if exist('sing_time','var')
        close(h)
        est_time = (n_file-i)*sing_time*1.1578e-05+now;
        waitSTR = sprintf('Image:  %d of %d \n Expected Time to End: %s',i,n_file,datestr(est_time));
        h = waitbar(i/n_file,waitSTR);
    else
        waitSTR = sprintf('Image:  1 of %d \n Expected Time to End: Unknown yet',n_file);
        h  = waitbar(1/n_file,waitSTR);        
    end
    tic % for calculating the estimated time

    % Display of the actual file in process
    disp(name)
    currentFile = strcat(input_directory, sep, files(i).name);

    % Read tif stack
    stack = ANtiffread(currentFile);

    % Detect the wells on the MIP image
    centers = HOUGHdetect(stack,r,rthick,quality,flt2do); 

    % Screen and sort the wells
    [centers, geometry] = well_screen(centers,r);
    if isempty(centers)
        % No proper well-screening: update the black-list
        warning(strcat('It was not possible to determine the grid geometry for image - ',name));
        BL_IND = BL_IND+1;
        black_list{BL_IND} = strcat(input_directory, sep, name); %#ok<*AGROW>
        BLACKFILE = strcat(input_directory, sep, 'BLACK_LIST.mat');
        save(BLACKFILE,'black_list','r','rthick','BLACK');
    else
        % Processing the image: chopping the single wells
        actual = 0;
        for row = 1:1:geometry(1)
            for col = 1:1:geometry(2)
                actual = actual+1;
                CC = cropWell(stack,centers(actual,:),r,rthick,0,BLACK); %#ok<*NASGU>
                instruction = strcat('crop_',num2str(row),num2str(col),' = CC;');
                eval(instruction);
            end
        end
        % Saving
        thisMatVar = strcat(currentFile(1:length(currentFile)-4),'_MANUALCOUNT.mat');
        save(thisMatVar, 'crop_*', 'geometry', '-mat');
        clear crop*
    end

    % Elapsed time for a single operation
    sing_timeT = toc;
    if exist('sing_time','var')
        sing_time = (sing_time+sing_timeT)/2;
    else
        sing_time = sing_timeT;
    end
end
BLACKFILE = strcat(input_directory, sep, 'BLACK_LIST.mat');
save(BLACKFILE,'black_list','r','rthick','BLACK');

close(h)
Message{1} = sprintf('Automatic Processing Complete: %d/%d',(n_file-length(black_list)),n_file);
Message{2} = sprintf('To process manually: %d',length(black_list));
Message{3} = sprintf('Type ''Black_PRO'' and press Enter.');
h = msgbox(Message,'Processing','warn');