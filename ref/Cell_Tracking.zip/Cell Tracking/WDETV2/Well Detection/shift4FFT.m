function Iout = shift4FFT(I,dim)
% ------------------------------------------------------------------------
% function Iout = shift4FFT(I,dim) realign an input image after FFT
% transformation.
%
%   Example:
% I =  [4     4     1     1     1     1     1     1
%       4     4     1     1     1     1     1     1
%       3     3     2     2     2     2     2     2
%       3     3     2     2     2     2     2     2
%       3     3     2     2     2     2     2     2
%       3     3     2     2     2     2     2     2
%       3     3     2     2     2     2     2     2
%       3     3     2     2     2     2     2     2
%       3     3     2     2     2     2     2     2
%       3     3     2     2     2     2     2     2];
% dim = 2;
% Correct arrangement is    13
%                           24
%
%   Output: - Iout: correct image (matrix nXm)
%
%   Input:  - I: after FFT image (matrix nXm)
%           - dim: smaller image dimension, depends on well (scalar)
%
% V. 1.0 - A. Negro, LSCB, EPFL, July 2009
% lscb.epfl.com
% ------------------------------------------------------------------------

% l & w are the dimensions of the original image plus the dimensions of 
% the pattern image 
[l,w]=size(I); 

% New image
d = zeros(l,w);
 
% To move the '4' to bottom-right position
d(l-dim+1:l,w-dim+1:w) = I(1:dim,1:dim);
 
% To move the '2' to top-left position
d(1:l-dim,1:w-dim) = I(dim+1:end,dim+1:end);
 
% To move the '3' to the right column
d(1:l-dim,w-dim+1:w) = I(1+dim:end,1:dim);
 
% To move the '1' to the bottom row
d(l-dim+1:l,1:w-dim) = I(1:dim,1+dim:w); 

Iout = d(dim+1:l-dim,dim+1:w-dim);

 