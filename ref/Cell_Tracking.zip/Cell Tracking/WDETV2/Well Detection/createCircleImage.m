function C = createCircleImage(r,rthick)

% ------------------------------------------------------------------------
% function C = createCircleImage(r,rthick) generates a fake well image.
%
%   Output: - C: fake well image (matrix 2r+21X2r+21)
%
%   Input:  - r: radius in pixel (scalar)
%           - ring thickness in pixel (scalar)
%
% V. 1.0 - A. Negro, LSCB, EPFL, July 2011
% lscb.epfl.com
% ------------------------------------------------------------------------

%% Image generation
dim = 2 * r + 21;
% Center of the circle
xc = r + 11;
yc = r + 11;
C = uint16(zeros(dim));
value = 255;
delta = floor(rthick / 2);

%% Multi-circle generation for having the ring shape
for radius = (r-delta):1:(r+delta);
    C = MidpointCircle(C, radius, xc, yc, value);
end

%% Fill eventual hole in the ring
for i = 2 : dim-1
    for j = 2 : dim-1
        if ~C(i,j)
            if (C(i+1,j)&&C(i-1,j)&&C(i,j-1)&&C(i,j+1))
                C(i,j)=255;
            end
        end
    end
end