function lettera = cellCONV(numero)

% ------------------------------------------------------------------------
% function lettera = cellCONV(numero) transform a column index from number 
% to letter format according with Excel cell distribution.
%
% INPUT: 
% - numero: column index in numeric format [integer scalar]
%
% OUTPUT:
% - lettera: column index in letter format (A if numero<=0) [string]
% ------------------------------------------------------------------------

% Converting array: Sequence of 546 (actually) possible columns
seq = {'A';'B';'C';'D';'E';'F';'G';'H';'I';'J';'K';'L';'M';'N';'O';'P';'Q';'R';'S';'T';'U';'V';'W';'X';'Y';'Z';
    'AA'; 'AB'; 'AC'; 'AD'; 'AE'; 'AF'; 'AG';'AH';'AI';'AJ';'AK';'AL';'AM';'AN';'AO';'AP';'AQ';'AR';'AS';'AT';'AU';'AV';'AW';'AX';'AY';'AZ';
    'BA'; 'BB'; 'BC'; 'BD'; 'BE'; 'BF'; 'BG';'BH';'BI';'BJ';'BK';'BL';'BM';'BN';'BO';'BP';'BQ';'BR';'BS';'BT';'BU';'BV';'BW';'BX';'BY';'BZ';
    'CA'; 'CB'; 'CC'; 'CD'; 'CE'; 'CF'; 'CG';'CH';'CI';'CJ';'CK';'CL';'CM';'CN';'CO';'CP';'CQ';'CR';'CS';'CT';'CU';'CV';'CW';'CX';'CY';'CZ';
    'DA'; 'DB'; 'DC'; 'DD'; 'DE'; 'DF'; 'DG';'DH';'DI';'DJ';'DK';'DL';'DM';'DN';'DO';'DP';'DQ';'DR';'DS';'DT';'DU';'DV';'DW';'DX';'DY';'DZ';
    'EA'; 'EB'; 'EC'; 'ED'; 'EE'; 'EF'; 'EG';'EH';'EI';'EJ';'EK';'EL';'EM';'EN';'EO';'EP';'EQ';'ER';'ES';'ET';'EU';'EV';'EW';'EX';'EY';'EZ';
    'FA'; 'FB'; 'FC'; 'FD'; 'FE'; 'FF'; 'FG';'FH';'FI';'FJ';'FK';'FL';'FM';'FN';'FO';'FP';'FQ';'FR';'FS';'FT';'FU';'FV';'FW';'FX';'FY';'FZ';
    'GA'; 'GB'; 'GC'; 'GD'; 'GE'; 'GF'; 'GG';'GH';'GI';'GJ';'GK';'GL';'GM';'GN';'GO';'GP';'GQ';'GR';'GS';'GT';'GU';'GV';'GW';'GX';'GY';'GZ';
    'HA';'HB';'HC';'HD';'HE';'HF';'HG';'HH';'HI';'HJ';'HK';'HL';'HM';'HN';'HO';'HP';'HQ';'HR';'HS';'HT';'HU';'HV';'HW';'HX';'HY';'HZ';
    'IA';'IB';'IC';'ID';'IE';'IF';'IG';'IH';'II';'IJ';'IK';'IL';'IM';'IN';'IO';'IP';'IQ';'IR';'IS';'IT';'IU';'IV';'IW';'IX';'IY';'IZ';
    'JA';'JB';'JC';'JD';'JE';'JF';'JG';'JH';'JI';'JJ';'JK';'JL';'JM';'JN';'JO';'JP';'JQ';'JR';'JS';'JT';'JU';'JV';'JW';'JX';'JY';'JZ';
    'KA';'KB';'KC';'KD';'KE';'KF';'KG';'KH';'KI';'KJ';'KK';'KL';'KM';'KN';'KO';'KP';'KQ';'KR';'KS';'KT';'KU';'KV';'KW';'KX';'KY';'KZ';
    'LA';'LB';'LC';'LD';'LE';'LF';'LG';'LH';'LI';'LJ';'LK';'LL';'LM';'LN';'LO';'LP';'LQ';'LR';'LS';'LT';'LU';'LV';'LW';'LX';'LY';'LZ';
    'MA';'MB';'MC';'MD';'ME';'MF';'MG';'MH';'MI';'MJ';'MK';'ML';'MM';'MN';'MO';'MP';'MQ';'MR';'MS';'MT';'MU';'MV';'MW';'MX';'MY';'MZ';
    'NA';'NB';'NC';'ND';'NE';'NF';'NG';'NH';'NI';'NJ';'NK';'NL';'NM';'NN';'NO';'NP';'NQ';'NR';'NS';'NT';'NU';'NV';'NW';'NX';'NY';'NZ';
    'OA';'OB';'OC';'OD';'OE';'OF';'OG';'OH';'OI';'OJ';'OK';'OL';'OM';'ON';'OO';'OP';'OQ';'OR';'OS';'OT';'OU';'OV';'OW';'OX';'OY';'OZ';
    'PA';'PB';'PC';'PD';'PE';'PF';'PG';'PH';'PI';'PJ';'PK';'PL';'PM';'PN';'PO';'PP';'PQ';'PR';'PS';'PT';'PU';'PV';'PW';'PX';'PY';'PZ';
    'QA';'QB';'QC';'QD';'QE';'QF';'QG';'QH';'QI';'QJ';'QK';'QL';'QM';'QN';'QO';'QP';'QQ';'QR';'QS';'QT';'QU';'QV';'QW';'QX';'QY';'QZ';
    'RA';'RB';'RC';'RD';'RE';'RF';'RG';'RH';'RI';'RJ';'RK';'RL';'RM';'RN';'RO';'RP';'RQ';'RR';'RS';'RT';'RU';'RV';'RW';'RX';'RY';'RZ';
    'SA';'SB';'SC';'SD';'SE';'SF';'SG';'SH';'SI';'SJ';'SK';'SL';'SM';'SN';'SO';'SP';'SQ';'SR';'SS';'ST';'SU';'SV';'SW';'SX';'SY';'SZ';
    'TA';'TB';'TC';'TD';'TE';'TF';'TG';'TH';'TI';'TJ';'TK';'TL';'TM';'TN';'TO';'TP';'TQ';'TR';'TS';'TT';'TU';'TV';'TW';'TX';'TY';'TZ'};

% Convesion
if numero > 0
    lettera = seq{numero};
else
    lettera = 'A';
end