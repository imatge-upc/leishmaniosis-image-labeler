function track=AddMum(track, division)
% ------------------------------------------------------------------------
% The  function AddMum get the mum id and the daughter id from the cell array division
%  and add a column of the mother indexes to track.
%
%   Input: -track: track structure obtained after several rounds of FPtrack and PostProcessing
%          -division: cell array containing the id of the mother and
%          daughter cells (e.g. division{i}= 2, 3, 4. Cell 2 is the mother
%          of 3 and 4).
%   Output: -track with a new column (11th) containing the mother id.
%
% V. 1.0 - F. P�lissier, LSCB, EPFL, December 2011
% lscb.epfl.com
% ------------------------------------------------------------------------

mum=zeros(size(division,1),1);
daughters=zeros(size(division,1),2);

for i=1:size(division,1)
    for j=1:length(division{i})/3
        mum(i)= division{i}(j*3-2);
       daughters(i,:)= [division{i}(j*3-1), division{i}(j*3)];
    end
end

for i=1:size(track,1)
    track(i,11)=0;
    frame = track(i,3);
    index=find(track(i,10)==daughters(frame,:));
    if ~isempty(index)
        track(i,11)=mum(frame);
        daughters(frame,index)=0;
    end
end
end