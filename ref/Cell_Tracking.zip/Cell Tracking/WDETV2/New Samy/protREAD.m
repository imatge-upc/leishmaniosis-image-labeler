function [PROTCOMB] = protREAD()

% ------------------------------------------------------------------------
% function [PROTCOMB] = protREAD() reads the experimental settings from an
% Excel file. It assign the right protein combination and randomization to
% proper fields.
%
%   Output: - PROTCOMB: initialized single field structure (struct)
%
%   Input:  - NONE
%
% V. 1.0 - A. Negro, LSCB, EPFL, July 2011
% lscb.epfl.com
% ------------------------------------------------------------------------

%% Selection and Reading of Excel info-sheet
% GUI selection
PROTCOMB=[];
[FileName,PathName] = uigetfile('C:\','Excel Combinatorial File','*.xls');
if FileName ~=0
filename = strcat(PathName,FileName);
% File reading
[~,~,raw] = xlsread(filename);
[~, categories] = size(raw);

%% Column Identification
% Find Image column
Img_ID = [];
for i = 1 : categories
    if strcmp(raw{1,i},'Image') % Maybe consider passing to strfind or similar
        Img_ID = i;
        break
    end 
end
if isempty(Img_ID)
    error('No Image column in the Excel File: check spaces and/or wrong naming');
end
% Find the Field column
Trans_ID = [];
for i = 1 : categories
    if strcmp(raw{1,i},'CMG2')
        Trans_ID = i;
        break
    end
end
if isempty(Trans_ID)
     error('No Transgene column in the Excel File: check spaces and/or wrong naming');
end
% Find the Prot column
Prot_ID = [];
for i = 1 : categories
    if strcmp(raw{1,i},'Prot')
        Prot_ID = i;
        break
    end
end
if isempty(Prot_ID)
     error('No Prot column in the Excel File: check spaces and/or wrong naming');
end
% Find the Randomization column
Rand_ID = [];
for i = 1 : categories
    if strcmp(raw{1,i},'Rando')
        Rand_ID = i;
        break
    end
end
if isempty(Rand_ID)
     error('No Rand column in the Excel File: check spaces and/or wrong naming');
end
raw = raw(2:end,:);
[records, ~] = size(raw);

%% Generation Protein Combination Matrixes
% Identification of the field
clear FID
for i = 1 : records
    IndF = strfind(raw{i,Img_ID},'F');
    Ind2 = strfind(raw{i,Img_ID},'_');
    FID{i} = raw{i,Img_ID}(IndF(1):Ind2(1)-1);
end
FID = unique(FID);
% Understanding the number of columns and rows
for i = 1 : records
    IndC = strfind(raw{i,Img_ID},'c');
    IndR = strfind(raw{i,Img_ID},'r');
    R(i) = str2double(raw{i,Img_ID}(IndR+1:IndC-2));
    C(i) = str2double(raw{i,Img_ID}(IndC(end)+1:length(raw{i,Img_ID})));
end
R = max(R);
C = max(C);
% Screening for each field
for i = 1 : length(FID)
    % Looking for field specific records
    IND = strfind(raw(:,Img_ID),FID{i});
    IND2 = [];
    for j = 1 : length(IND)
        if ~isempty(IND{j})
            IND2(j) = 1;
        else
            IND2(j) = 0;
        end
    end
    IND = find(IND2~=0,R*C,'first');
    RAW = raw(IND,:);
    for j = 1 : R*C
        IndC = strfind(RAW{j,Img_ID},'c');
        IndR = strfind(RAW{j,Img_ID},'r');
        Rt = str2double(RAW{j,Img_ID}(IndR+1:IndC(end)-2));
        Ct = str2double(RAW{j,Img_ID}(IndC(end)+1:length(RAW{j,Img_ID})));
        info(Rt,Ct).Prot = RAW{j,Prot_ID};
        info(Rt,Ct).trans = RAW{j,Trans_ID};
        info(Rt,Ct).rando = RAW{j,Rand_ID};
    end
    comando = sprintf('PROTCOMB.%s=info;',FID{i});
    eval(comando);
end
end
