function d = distance_other(obj, stat)
% ------------------------------------------------------------------------
% distance_other computes the distance of an object from its neighbors
%
%   Input: -obj: object from stat obtained with regionprops.
%          -stat: object statistics from regionprops.
%   Output: -d: euclidean distance between obj and its neighbors.
%
% V. 1.0 - F. P�lissier, LSCB, EPFL, December 2011
% lscb.epfl.com
% ------------------------------------------------------------------------

d=1000 * ones(size(stat,1),1);
x0 = obj.Centroid(1);
y0 = obj.Centroid(2);

for i=1:size(stat,1)
    x = stat(i).Centroid(1);
    y = stat(i).Centroid(2);
    if stat(i).Area < 5000 && (x ~= x0 || y ~=y0)
        d(i) = sqrt((x-x0)^2 + (y-y0)^2);
    end
end
end