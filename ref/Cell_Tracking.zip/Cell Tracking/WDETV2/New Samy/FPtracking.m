function [trackproc, Output] = FPtracking(VIDEO, param)
% ------------------------------------------------------------------------
% FPtracking function performs the cell segmentation and tracking
% process.
%In CellTracking: [Array(R,C).Tracks, Array(R,C).Output]  = FPtracking(I,param);
%
%   Input: -VIDEO: video of images with cells to track cut after well detection. 
%          -param: structure containing the parameters of the experiments
%
%  Output: -trackproc: matrix containg the information of each cell:
%                       % 10 columns
%                           1- X
%                           2- Y
%                           3- Frame
%                           4- Area
%                           5- Eccentricity
%                           6- Solidity
%                           7- Mean Intensity
%                           8- In/out of the well (0/1)
%                           9- Dive-in (1) / Nothing (0)/ Jump-off (-1)
%                           10- Cell identification
%                           11- Mother cells
%            -Output: structure containing fields ProlRatebase, ProlRate, 
%                     DeathRate, tree, OverallDistance, MeanAreas,
%                       MeanEccentricity, MeanSolidity,
%                       DistanceFromEachOther and MeanIntensity
%
% V. 1.0 - F. P�lissier, A. Negro, LSCB, EPFL, December 2011
% lscb.epfl.com
% ------------------------------------------------------------------------
%% Tracking legend


%% Particle Detection
tracks = [];
tStart =tic;
% repetition over the entire time-lapse
for i = 1 : length(VIDEO)
    %%
    i %#ok<NOPRT>
    %Check if the well is empty
    if max(max(VIDEO{i})) > 500
        
        I = VIDEO{i};
        % This code diplays the virtual well to check where the cells are.
        % mask3 should be define in the mask of the well part
%             In=I;
%             for j=1:size(I,1)
%                 for k=1:size(I,2)
%                     if mask3(j,k) ==1;
%                         In(j,k) = max(max(I));
%                     end
%                 end
%             end
%             figure, imagesc(In);
        h = fspecial('average');
        I1 = imfilter(I,h);
        h= fspecial('gaussian', 5, 3);
        I2 = imfilter(I1,h);
        %     figure, imagesc(I2);
        I3 = I2 - mean(mean(I2));
        b = 0.4*ones(size(I3));
        dx =1;
        dy=1;
        % Level set method- May be reduce iteration numbers
        I4 = evolve2D(double(I3),dx,dy,0.9,80,'WENO',[],0,[],0,[],[],1,b);
        I4 = uint16(I4);
        %     figure, imagesc(I4);
        [mu,I5]=kmeans(I4,20);
        % If it takes to much time for the kmeans method to run, mu is set to
        % zero using tic toc method in kmeans
        if mu ~= 0
            %Regional maximums are found as mask for the watershed method
            mask = imregionalmax(I5);
            % figure, imagesc(mask)
            stat_mask = regionprops(mask,I3,'Area','Centroid', 'MeanIntensity','PixelList');
            % We remove false positive using mask_correction function
            mask_corr = mask_correction(mask, stat_mask, param.cellsize);
            %  figure, imshow(mask_corr);
            % We set an arbitraty threshold from image from kmeans to get the
            % foreground.
            bw = I5 >4;
            % bw = im2bw(Ieq, graythresh(Ieq));
            % figure, imshow(bw)
            bw = bwareaopen(bw, 50);
            % We have to dilate the foreground in order the mask does not touch
            % the border of the foreground.
            bw = imdilate(bw, ones(8,8));
            
            %Watershed method
            I_eq_c = imcomplement(I);
            I_mod = imimposemin(I_eq_c, ~bw | mask_corr);
            
            L = watershed(I_mod);
%             figure, imshow(label2rgb(L))
%                     i=i+1;
            %%
            %%
            % Statitics evaluation
            stat = regionprops(L,I,'Area','Centroid', 'Eccentricity', 'Solidity', 'MeanIntensity');
            coo = [];
            cooinfo = [];
            counter = 0;
            
            for j = 1 : length(stat)
                d = distance_other(stat(j), stat);
                if (stat(j).Area>param.minarea || isempty(find(d<20,1))) && (stat(j).Area < 8000 ...
                        && stat(j).MeanIntensity> 200 && stat(j).Area > 100)
                    coo = [coo; stat(j).Centroid]; %#ok<AGROW>
                    cooinfo = [cooinfo; stat(j).Area, stat(j).Eccentricity, stat(j).Solidity,  stat(j).MeanIntensity]; %#ok<AGROW>
                    counter = counter +1;
                    
                end
            end
            coo = [coo, i*ones(counter,1),cooinfo]; %#ok<AGROW>
            tracks = [tracks; coo]; %#ok<AGROW>
            telapse2 = toc(tStart); %#ok<NASGU>
        end
    end
end

%% Tracking:
% Cell in the well: dive in / jump out
% Mask of the well
mask = createCircleImage(param.r,param.rthick);
[r,c] = size(mask);
mask2 = zeros(r+2*(param.border+param.marg),c+2*(param.border+param.marg));
mask2(param.border+param.marg+1:r+param.border+param.marg,param.border+1+param.marg:c+param.border+param.marg) = mask;
mask = mask2;
mask = imdilate(mask, strel('disk', 40));
mask = imfill(mask, 'holes');
% mask3 is used to display the well on the picture
% mask3=bwperim(mask);

% Logical mask
mask = mask&1;
% Screening through the entire population of events
in0out = zeros(size(tracks,1),1);
for i = 1 : size(tracks,1)
    if mask(round(tracks(i,1)),round(tracks(i,2)))
        in0out(i) = 1;
    end
end
tracks = [tracks,in0out];

%%
% Screening for dive-in / jump-off
% CODE: +1 dive-in / 0 nothing / -1 jump-off
divejump = zeros(size(tracks,1),1);
CellsIn =zeros(length(VIDEO),2);
CellsOut =zeros(length(VIDEO),2);

for i = 1 : size(tracks,1)
    index = tracks(i,3);
    CellsIn(index,1) = CellsIn(index,1) + tracks(i,end);
    CellsIn(index,2) = i;
    
    if tracks(i,end)==0
        CellsOut(index,1)=CellsOut(index,1) +1;
        CellsOut(index,2) = i;
    end
end

for i=2:length(CellsIn)
    if CellsIn(i,1) > CellsIn(i-1,1) && CellsOut(i,1) < CellsOut(i-1,1)
        divejump(CellsIn(i,2))= CellsOut(i-1,1)-CellsOut(i,1);
    end
    
    if CellsIn(i,1) < CellsIn(i-1,1) && CellsOut(i,1) > CellsOut(i-1,1)
        divejump(CellsIn(i,2))= CellsOut(i-1,1)-CellsOut(i,1);
    end
end
tracks = [tracks, divejump];

%%
% Handling false positives and false negatives
if ~isempty(tracks)
    finaltracks=[]; %#ok<NASGU>
    [finaltracks, jump] = correction(tracks, length(VIDEO));
end
if ~isempty(tracks) && ~isempty(finaltracks)
    %%
    %Cost computing
    [tracks2, Idcat, deathid, division, jump2,~] = FPtrack(finaltracks,jump, length(VIDEO));
    %Post process
    tracks2 = PostProcess(tracks2, Idcat, deathid, division);
    %After the post processing, we run another round of tracking and post
    %processing to get the good cell id
    [tracks2, Idcat2, deathid2, division2, jump3, ~] = FPtrack(tracks2,jump2, length(VIDEO));
    trackproc = PostProcess(tracks2, Idcat2, deathid2, division2);
    [trackproc, Idcat2, deathFinal, divisionFinal, jump3, cellN] = FPtrack(trackproc,jump3, length(VIDEO));
    
    %Add the last column to trackproc which is the array of cell ids
    trackproc(:,end+1)=Idcat2;
    
    %% Output
    [Output.ProlRatebase, Output.ProlRateAdvance, Output.Deathrate, Output.tree, Output.Overalldistance, ...
        Output.MeanAreas, Output.MeanEccentricity, Output.MeanSolidity, Output.DistanceFromEachOther ,Output.MeanIntensity]...
        = output(trackproc, divisionFinal, deathFinal, cellN);
    Output.ProlRatebase=Output.ProlRatebase-sum(jump3);
    
    %% Cell Analysis
    trackproc= AddMum(trackproc, divisionFinal);
else
    %if finaltracks is empty
    Output.ProlRatebase={'empty'};
    Output.ProlRateAdvance={'empty'};
    Output.Deathrate={'empty'};
    Output.Overalldistance(1)={'empty'};
    Output.Overalldistance(2)={'empty'};
    Output.MeanAreas(1) ={'empty'};
     Output.MeanAreas(2) ={'empty'};
    Output.MeanEccentricity(1) ={'empty'};
    Output.MeanEccentricity(2) ={'empty'};
    Output.MeanSolidity(1) ={'empty'};
    Output.MeanSolidity(2) ={'empty'};
    Output.DistanceFromEachOther(1) ={'empty'};
    Output.DistanceFromEachOther(2) ={'empty'};
    Output.MeanIntensity(1) ={'empty'};
    Output.MeanIntensity(2) ={'empty'};
    trackproc=[];
end
end
