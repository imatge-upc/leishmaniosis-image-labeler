function goodField = goodfield(stru,tofind)

% ------------------------------------------------------------------------
% function goodField = goodfield(stru,tofind) look for a field within a
% structure.
%
%   Output: - goodField: name of the field (cell array nX1)
%
%   Input:  - stru: structure of data (struct of uwell platform)
%           - tofind: string to look for (string)
%
% V. 1.0 - A. Negro, LSCB, EPFL, December 2011
% lscb.epfl.com
% -----------------------------------------------------------------------

goodField = [];
% Looking for field names 
fields = fieldnames(stru);
% Looking for WL label. ID is a key-sequence in field names
match = strfind(fields, 'ID');
% Screen for interesting fields
indOK = [];
for i = 1 : length(match)
    if ~isempty(match{i})
        indOK = [indOK, i]; %#ok<*AGROW>
    end
end
% Identified fields are further scanned for tofind sequence
WLID = [];
for i = 1 : length(indOK)
    % I'm looking for something inside: name name of the wave-length
    comando = sprintf('varo = stru.%s;',fields{indOK(i)});
    eval(comando);
    BF1 = strfind(varo,tofind);
    % In match is positive: save it
   if ~isempty(BF1)
        ind = indOK(i);
        indOK(i) = 0;
    end
end
% Return the name of the field
goodField = fields{ind}(1:end-2);