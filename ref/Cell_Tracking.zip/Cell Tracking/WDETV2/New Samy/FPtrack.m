function [track, Idcat, deathid, division, jump, cell_number] = FPtrack(track,jump, len)
% ------------------------------------------------------------------------
% FPtrack executes the tracking of the cells using a cost matrix and assign
% identification to cells
% [tracks2, Idcat, deathid, division, jump2, cellN] = FPtrack(finaltracks,jump, length(VIDEO));
%
%   Input: -track: matrix of track after correction function in CellTracking function
%          -jump: array containing the information if a cell jumped after
%          correction function
%          -len= length(video)
%
%   Output: - track: matrix of track modified
%           -Idcat: identification of cells concatenated to add to track as
%   a new column.
%           -deathid: cell array containing the identification of the dead
%        cells. deathid{t} = 2,3 e.g
%           -division: cell array containing the identification of the
%        divisions. E.g if cell number 2 divided in 4 and 5-> division{t} = 2,
%        4,5.
%           -jump: array containing the information if a cell jumped modified
%           -cell_number: array containing the number of cells at each time
%        frame
%
% V. 1.0 - F. P�lissier, LSCB, EPFL, December 2011
% lscb.epfl.com
% ------------------------------------------------------------------------

% 4: Area, 5: Eccentricity, 6: Solidity, 7: Mean Intensity

%% Properties computing
% clear Idcat prop cost cost2 id division deathid TotalCost
% Initialization
prop(len) = struct('area',{[]},'ecc',{[]},'sol',{[]},'intensity',{[]},'position',{[]});
cost(len) = struct('area',{[]},'intensity',{[]},'distance',{[]});
cost2 = cost;
TotalCost = cell(len,1);
id= cell(len,1);
division=cell(len,1);
deathid=cell(len,1);
Idcat = [];

for i = 1 : size(track,1)
    index = track(i,3); % Time frame
    if index ==track(1,3) % Initialize the first ids
        id{index}= [id{index},i];
        %death contains the maximum id to refere when a division happen
        %(e.g if death is 5, newborns will be 6 and 7 (and more)
        death = max(id{index});
    end
    
    % Define the properties of each cell
    prop(index).area=[prop(index).area; track(i,4)];
    prop(index).ecc=[prop(index).ecc; track(i,5)];
    prop(index).sol=[prop(index).sol; track(i,6)];
    prop(index).intensity=[prop(index).intensity; track(i,7)];
    prop(index).position=[prop(index).position; track(i,1:2)];
    
end

%%
%Then calculate cost
for i=1:size(prop,2)-1
    % I think we can remove this if because id{i} would never be empty
    if isempty(prop(i).area)
        id{i}=[];
        id{i+1}=[death+1:death+length(prop(i+1).area)]'; %#ok<NBRAK>
    else
        %If there are no cell in the next time frame but not in the third
        %one, it means cells were not found
        if i < size(prop,2)-2 && isempty(prop(i+1).area) && ~isempty(prop(i+3).area)
            %We give the id and the property values of the previous frame
            id{i+1}=id{i};
            prop(i+1)=prop(i);          
            % Add the lacking part to track
            toadd = find(i==track(:,3));
            track = [track(1:toadd(end),:); track(toadd,:); track(toadd(end)+1:end,:)];
            track(toadd(end)+1:toadd(end)+length(toadd),3)=i+1;
            
            if isempty(prop(i+2).area)
                id{i+2}=id{i};
                prop(i+2)=prop(i);
                toadd = find(i+1==track(:,3));
                track = [track(1:toadd(end),:); track(toadd,:); track(toadd(end)+1:end,:)];
                track(toadd(end)+1:toadd(end)+length(toadd),3)=i+2;
            end
            jump(i+1)=0;
            jump(i+2)=0;
            jump(i+3)=0;
        else
            %Otherwise, it means cells died
            if i > size(prop,2)-2 && isempty(prop(i+1).area)
                deathid{i+1}=[deathid{i+1},id{i}];
            else
                if i < size(prop,2)-2 && isempty(prop(i+1).area) && isempty(prop(i+3).area)
                    deathid{i+1}=[deathid{i+1},id{i}];
                else
                    
                    %If there is only one cell in the 2 frames, we assign
                    %the same id
                    if size(prop(i).area,1) == 1 && size(prop(i+1).area,1) == 1
                        id{i+1}=id{i};
                    else
                        for j=1:size(prop(i).area,1)
                            for k=1:size(prop(i+1).area,1)
                                % Cost of the area and intensity are computed by the log2
                                % of the difference, but we add 0.5 to
                                % avoid zero
                                cost(i).area(j,k) =abs(log2(prop(i).area(j)-prop(i+1).area(k) + 0.5));
                                cost(i).intensity(j,k)=abs(log2(prop(i).intensity(j)-prop(i+1).intensity(k) + 0.5));
                                % Cost of the distance is computed using
                                % euclidean distance
                                x0 = prop(i).position(j,1)+0.0000001;
                                y0 = prop(i).position(j,2)+0.0000001;
                                x = prop(i+1).position(k,1);
                                y = prop(i+1).position(k,2);
                                cost(i).distance(j,k) = sqrt((x-x0)^2 + (y-y0)^2);
                            end
                        end
                        % Normalization
                        std_area=std2(cost(i).area);
                        if std_area ==0
                            std_area=1;
                        end
                        std_intensity=std2(cost(i).intensity);
                        if std_intensity ==0
                            std_intensity =1;
                        end
                        std_distance=std2(cost(i).distance);
                        if std_distance==0
                            std_distance=1;
                        end
                        cost2(i).area = (cost(i).area - mean2(cost(i).area)) / std_area;
                        cost2(i).intensity = (cost(i).intensity - mean2(cost(i).intensity)) / std_intensity;
                        cost2(i).distance = (cost(i).distance - mean2(cost(i).distance)) / std_distance;
                        
                        %Total cost matrix
                        %weights:
                        w1 = 1; w2=1; w3=5; %to improve
                        TotalCost{i} = w1*cost2(i).area + w2*cost2(i).intensity + w3*cost2(i).distance;
                        
                        I=[]; %#ok<NASGU>
                        J=[]; %#ok<NASGU>
                        s=[size(prop(i).area,1), size(prop(i+1).area,1)];
                        % The Hungarian method is used to minimze the cost
                        % matrix
                        assign= Hungarian(TotalCost{i});
                        index= find(assign==1);
                        [I, J]=ind2sub(s,index);
                        
                        % Some cells will not be assigned when they divide
                        % or they die, so we create a new matrix to assign
                        % these non-assigned cells
                        matrix=TotalCost{i};
                        ind2=0;
                        while ~isempty(ind2)
                            ind=[];
                            ind2=[];
                            for s2=1:size(assign,2) %Column
                                if max(assign(:,s2))==1
                                    ind=[ind,s2]; %#ok<AGROW>
                                else
                                    ind2 = [ind2,s2]; %#ok<AGROW>
                                end
                            end
                            if ~isempty(ind2)
                                matrix2=matrix(:,ind2);
                                assign2=Hungarian(matrix2);
                                index= find(assign2==1);
                                [~,index2]=ismember(matrix2(index),matrix(:,ind2)); %#ok<FNDSB>
                                [I2, J2]=ind2sub(s,index2);
                                I=[I;I2]; %#ok<AGROW>
                                J=[J;ind2(J2)']; %#ok<AGROW>
                                assign(I2,ind2(J2))=1;
                            end
                        end
                        index=[]; %#ok<NASGU>
                        [~,index] = ismember(sort(J),J);
                        J=J(index);
                        I=I(index);
                        %% Event handlings from the assigned matrix
                        %No event
                        if  size(prop(i).area,1) == size(prop(i+1).area,1)
                            id{i+1}=id{i}(J);
                            jump(i+1)=0;
                        end
                        
                        %Death and jump out
                        if size(prop(i).area,1) > size(prop(i+1).area,1)
                            id{i+1}=id{i}(I);
                            for j=1:length(id{i})
                                if isempty(find(j==I)) %#ok<EFIND>
                                    %Store the id of the dead cells
                                    deathid{i+1}=[deathid{i+1},id{i}(j)];
                                end
                            end
                            %If cells jumped, they did not die, so we dont
                            %store their ids.
                            deathid{i+1}=deathid{i+1}(1:end+jump(i+1));
                        end
                        
                        %mitosis and jump in
                        if  size(prop(i).area,1) < size(prop(i+1).area,1)
                            %addcell contains the number of cells wich
                            %actually divided and did not jump
                            addcell =size(prop(i+1).area,1)- size(prop(i).area,1)-jump(i+1);
                            
                            count=1;
                            ind0=[];
                            %mitosis
                            for j=1:length(id{i})
                                if count <= addcell
                                    if length(find(j==I)) >1 %A mother cell has been assigned to 2 daughter cells
                                        ind = find(j==I);
                                        if length(ind)>2 %  In case a cell has been assigned to more than 2 daughter cells
                                            ind0 =ind;
                                        end
                                        id{i+1}(J(ind(1:2)))= death+1:death+length(J(ind(1:2)));
                                        %Store the id of the mother and the
                                        %daughters
                                        division{i+1}= [division{i+1},id{i}(j),death+1, death+length(ind(1:2))];
                                        death = death+length(ind(1:2));
                                        count = count+1;
                                    else
                                        id{i+1}(J(find(j==I)))= id{i}(j); %#ok<FNDSB>
                                    end
                                else
                                    %jump in
                                    ind=[]; ind2=[]; %#ok<NASGU>
                                    if length(find(j==I)) >1 % A cell has been assigned to itself and the jumped cell
                                        newind=find(j==I);
                                        %Find the cells which jumped = the
                                        %worst Cost
                                        ind = sort(TotalCost{i}(j,J(newind)));
                                        [~, ind2]=ismember(ind(2:length(newind)),TotalCost{i});
                                        [Ijump, Jjump]=ind2sub(s,ind2); %#ok<ASGLU>
                                        [~,ind2]=ismember(Jjump,J);
                                        %Create new ids
                                        id{i+1}(J(ind2))= death+1:death+length(Jjump);
                                        ind=setxor(newind,ind2);
                                        
                                        id{i+1}(J(ind)) = id{i}(j);
                                        death = death+size(Jjump,2);
                                    else
                                        newind=find(j==I);
                                        id{i+1}(J(newind))= id{i}(j); %#ok<FNDSB>
                                    end
                                end
                                % This part handles multiassignment =
                                % conflict, when cells divide and jump at
                                % the same time
                                ind=[]; ind2=[]; %#ok<NASGU>
                                if ~isempty(ind0(3:end))
                                    newind=ind0(3:end);
                                    %Look at the cost
                                    ind = sort(TotalCost{i}(j,J(newind)));
                                    [~, ind2]=ismember(ind(1:length(newind)),TotalCost{i});
                                    [Ijump, Jjump]=ind2sub(s,ind2); %#ok<ASGLU>
                                    [~,ind2]=ismember(Jjump,J);
                                    id{i+1}(J(ind2))= death+1:death+length(Jjump);
                                    ind=setxor(newind,ind2);
                                    
                                    id{i+1}(J(ind)) = id{i}(j);
                                    death = death+size(Jjump,2);
                                    ind0=[];
                                end
                            end
                        end
                    end
                    
                end
            end
        end
    end
    
    
    if size(id{i},2)~=1
        id{i}=id{i}';
    end
    % Concatenation of ids
    Idcat=[Idcat;id{i}]; %#ok<AGROW>
end

if size(id{end},2)~=1
    id{end}=id{end}';
end
Idcat=[Idcat;id{end}];

cell_number = zeros(length(division),1);
for i = 1 : size(track,1)
    index = track(i,3); %Time frame
    if index==0
        break
    end
    cell_number(index) = cell_number(index)+1; %Count the number of cells inside a well
end

for i=1: size(track,1)
    index = track(i,3); %Time frame
    track(i,9)=jump(index);
end
end