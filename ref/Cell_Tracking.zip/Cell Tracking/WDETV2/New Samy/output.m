function [ProlRatebase, ProlRate, DeathRate, tree, OverallDistance, MeanAreas, MeanEccentricity, MeanSolidity, DistanceFromEachOther, MeanIntensity ] =...
    output(track,division, deathid,  cellN)
% ------------------------------------------------------------------------
% Output function computes the proliferation rate, the death rate, the
% distance travelled by cells, the mean of the areas of all the cells, the
% mean of the eccentricity, the mean of the solidity, the mean of the
% distance of the cells between each other on each frame, and the mean of
% the GFP intensity of the cells.
%
%In FPtracking: [Output.ProlRatebase, Output.ProlRateAdvance, Output.Deathrate, Output.tree, Output.Overalldistance, ...
%        Output.MeanAreas, Output.MeanEccentricity, Output.MeanSolidity,
%        Output.DistanceFromEachOther ,Output.MeanIntensity]...
%        = output(trackproc, divisionFinal, deathFinal, cellN);
%
%   Input: -track: matrix containing the track after rounds of tracking and post processing
%          -division: cell array containing the identification of the
%        divisions. E.g if cell number 2 divided in 4 and 5-> division{t} = 2,
%        4,5.
%          -deathid: cell array containing the identification of the dead
%        cells. deathid{t} = 2,3 e.g
%          -cellN: array containg the cell number at each time frame
%
%  Output: -ProlRatebase: base proliferation rate computed with cell
%  number at the end and cell number at the beginning.
%         - ProlRate: proliferation rate computed with the number of
%         divisions divided by the initial number of cells.
%          -DeathRate: death rate computed with the number of dead cells
%          divided by the initial cell number.
%          -tree: not yet implemented
%         - OverallDistance= mean of the travelled distance by each cell
%          -MeanAreas = mean of the areas of each cell.
%          -MeanEccentricity= mean of the eccentricity of each cell
%          -MeanSolidity= mean of the solidity of each cell
%          -DistanceFromEachOther = distance of the cells between each
%          other.
%          -MeanIntensity = mean of the intensity of each cell.
%
% V. 1.0 - F. P�lissier, A. Negro, LSCB, EPFL, December 2011
% lscb.epfl.com
% ------------------------------------------------------------------------
%% Proliferation rate
%Initialisation
NDeath =0;
NDivision=0;
DeathRate =0;
ProlRate=0;
distance = cell(max(track(:,end)),1);
distance2 = cell(max(track(:,3)),1);
position = cell(max(track(:,end)),1);
coor = cell(max(track(:,3)),1);
CellmeanDistance=zeros(max(track(:,end)),1);
DistancePerFrame=zeros(max(track(:,end)),1);
tree=[];
MeanAreas=[0 0];
MeanEccentricity=[0 0];
MeanSolidity = [0 0];
MeanIntensity = [0 0];

% Death number
for i=1:length(deathid)
    if ~isempty(deathid{i})
        NDeath=NDeath +length(deathid{i});
    end
end

cellN2=cellN(cellN~=0);
CellNinitial = cellN2(1);
ProlRatebase= cellN(end)/cellN2(1);

%Proliferation rate
for i=1:length(division)
        if ~isempty(division{i})
            NDivision=NDivision+length(division{i})/3;
        end
end

if CellNinitial~=0
    DeathRate = NDeath/CellNinitial;
    ProlRate = NDivision/CellNinitial;
end

%% Travelled distance
for i=1:size(track,1)
    id = track(i,end);
    position{id}= [position{id}; track(i,1:2)];
end

for i=1:length(position)
    if size(position{i},1) ~= 1
        for j=1:size(position{i},1)-1
            
            x0= position{i}(j,1);
            y0= position{i}(j,2);
            x= position{i}(j+1,1);
            y= position{i}(j+1,2);
            
            distance{i}= [distance{i} ; sqrt((x-x0)^2 + (y-y0)^2)];
        end
        if ~isempty(distance{i})
         CellmeanDistance(i)= mean(distance{i});
        else
             CellmeanDistance(i)=[];
        end
        
    end
end
OverallDistance(1)=mean(CellmeanDistance);
OverallDistance(2)=std(CellmeanDistance);

%% Mean Areas, Eccentricity, Solidity
areas= track(:,4);
MeanAreas(1) = mean(areas);
MeanAreas(2) = std(areas);
eccentricity=  track(:,5);
MeanEccentricity(1) = mean(eccentricity);
MeanEccentricity(2) = std(eccentricity);
solidity = track(:,6);
MeanSolidity(1) = mean(solidity);
MeanSolidity(2) = std(solidity);
intensity = track(:,7);
MeanIntensity(1) = mean(intensity);
MeanIntensity(2)= std(intensity);
%% Position from each other
for i=1:size(track,1)
    frame = track(i,3);
    coor{frame}= [coor{frame}; track(i,1:2)];
end

for i=1:length(coor)
   if size(coor{i},1) > 1
        for j=1:size(coor{i},1)-1
            for k=j+1:size(coor{i},1)
            x0= coor{i}(j,1);
            y0= coor{i}(j,2);
            x= coor{i}(k,1);
            y= coor{i}(k,2);
            
            distance2{i}= [distance2{i} ; sqrt((x-x0)^2 + (y-y0)^2)];
            end
        end
        if ~isempty(distance2{i})
         DistancePerFrame(i)= mean(distance2{i});
        else
             DistancePerFrame(i)=[];
        end
        
    end
end
DistanceFromEachOther(1) = mean(DistancePerFrame);
DistanceFromEachOther(2) = std(DistancePerFrame);
%% Tree
% To make:
% I have found several Matlab funtions: treeplot, biograph..
end