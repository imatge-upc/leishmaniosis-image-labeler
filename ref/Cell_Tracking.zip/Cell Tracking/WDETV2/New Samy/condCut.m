 function video = condCut(v,centers,param)
 
% ------------------------------------------------------------------------
% function video = condCut(v,centers,param) crop microwell video and
% align it at the mean time.
%
%   Output: - video: cropped single microwell video (cell array nX1)
%
%   Input:  - video: single microwell video (cell array nX1)
%           - centers: centers over time (matrix nX2)
%           - param: structure with cropping parameters
%               .r: well radius in pixel (scalar)
%               .rthick: ring thickness in pixel (scalar)
%               .marg: margin around the well (scalar)
%               .border: addictional border around in pixel (scalar)
%
% V. 1.0 - A. Negro, LSCB, EPFL, July 2011
% lscb.epfl.com
% ------------------------------------------------------------------------

 video = [];
 for i = 1 : length(v)
     I = v{i};
     I = cropWell(I,centers(i,:),param.r,param.rthick,param.marg,param.border,0);
     video = [video, {I}]; %#ok<*AGROW>
 end