function [stack,centerV] = alignStack(video,param)
 % Funtion to align a stack of well
 stack = [];
 center=[];
 centerV = [];
 for i = 1 : length(video)
     I = video{i};
     center{i} = FFTdetect(I,param.r,param.rthick,param.way);
     if ( isempty(center{i}) || size(I,1)- center{i}(1) < 200 || size(I,2)-center{i}(2) < 200) && i>1
         center{i}=center{i-1};
     end
     single = cropWell(I,center{i},param.r,param.rthick,param.border,param.marg,0);
     stack{i}=single; %#ok<*AGROW>
     centerV(i,1:2) = center{i};
 end
 
 