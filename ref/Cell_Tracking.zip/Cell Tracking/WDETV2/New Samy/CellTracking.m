function CellTracking(FF, list_of_file, param, fatherDIR, subDIRlist)
% ------------------------------------------------------------------------
% CellTracking function is the main of the segmentation/tracking process
% after the initialization part.
%
%   Input: -FF: field to analyze. In the start.m program, there is a loop
%   over the fields.
%          -list_of_file: cell array containg the list of files of all the
%          fields. Obtained after initialization.
%          -param: structure containing the parameters of the experiments
%          (radius of the well,etc) obtained after initialization.
%          -fatherDIR: directory path containing the videos in subfolders.
%          -subDIRlist: cell array containing the list of the subfolders
%          (F1 to F20 eg)
%
%  Output: nothing, this function writes 2 excel files in dlm format
%  (F1.xls and F1_CellResults.xls e.g. in a "results" folder).
%
% V. 1.0 - F. P�lissier, A. Negro, LSCB, EPFL, December 2011
% lscb.epfl.com
% ------------------------------------------------------------------------
%%
% For having a system-indpendent software
sep = '\';
if ismac
    sep = '/';
end
%% Excel file preparation
xlsfile= strcat('results',sep, subDIRlist{FF},'.xls');
hdr={'Field','Rando','Row', 'Column', 'Prol Rate Base', 'Prol Rate Computed',...
                'Death Rate', 'Mean Travelled Distance', 'std', 'Mean Area', 'std', ...
                'Mean Eccentricity', 'std', 'Mean Solidity', 'std', 'Mean Distance from each other', 'std','Mean Intensity', 'std'};
txt=sprintf('%s\t',hdr{:});
txt(end)='';
dlmwrite(xlsfile, txt,'delimiter', '','-append');

hdr={'Field','Rando','Row', 'Column', 'x', 'y', 'Frame', 'Area', 'Eccentricity', 'Solidity','Mean Intensity',...
    'Jump', 'Cell id', 'Mother Cell'};
txt=sprintf('%s\t',hdr{:});
txt(end)='';
cellfile= strcat('results',sep, subDIRlist{FF},'_CellResults.xls');
dlmwrite(cellfile, txt,'delimiter', '','-append');

%% Stack Alignment: single frame well-detection and cropping (BF and GFP)
% load the file
clear Array
load(list_of_file{FF});
% Prepare the list of wave_length: BF first element
WLID = look4BF(Array(1,1)); %#ok<NODEF>
% count = 0;
% For tracking purposes: system dependent
% WL2TR = 'GFP';
% goodField = goodfield(Array(1,1),WL2TR); %Check this function, we dont use it...
% Cycles over the array
err=[];
for R = 1 :  size(Array,1)
    for C = 1 : size(Array,2)
        cd(fatherDIR);
%         count = count +1
        % Well detetction and crop on BF
        comando = sprintf('BF = ANtiffread(Array(R,C).%s);',WLID{1});
        eval(comando);
        [BFcorr, centers] = alignStack(BF,param); %#ok<ASGLU>
        % Apply crop over all the other WL
        for W = 2 : length(WLID)
            comando = sprintf('I = ANtiffread(Array(R,C).%s);',WLID{W});
            eval(comando);
            I = condCut(I,centers,param);
        end
        %% Cell Tracking
        try
            [Array(R,C).Tracks, Array(R,C).Output]  = FPtracking(I,param); %#ok<AGROW>
            
            %% Results writting
            % Well Analysis
            array=[{subDIRlist{FF}}, {Array(R,C).Rando}, R, C, Array(R,C).Output.ProlRatebase,  Array(R,C).Output.ProlRateAdvance...
                 Array(R,C).Output.Deathrate, Array(R,C).Output.Overalldistance, Array(R,C).Output.MeanAreas, Array(R,C).Output.MeanEccentricity,...
                 Array(R,C).Output.MeanSolidity, Array(R,C).Output.DistanceFromEachOther, Array(R,C).Output.MeanIntensity]; %#ok<CCAT1>
             
             track= Array(R,C).Tracks;
             if ~isempty(track)
                 array=sprintf('%s\t%s\t%g\t%g\t%g\t%g\t%g\t%g\t%g\t%g\t%g\t%g\t%g\t%g\t%g\t%g\t%g\t%g\t%g',array{:});
                 len=size(track,1); %len contains the size of the track, but if track is empty it should be set to one
                                    % in order to write the empty line.
             else
                 array=sprintf('%s\t%s\t%g\t%g\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s',array{:});
                 len=1;
             end
             array(end)='';
            
            dlmwrite(xlsfile, array,'delimiter', '','-append');
            
            %Cell Analysis
            matrix=cell(1,14);
                       
            for i=1:len
                matrix{1}=subDIRlist{FF};
                matrix{2}=Array(R,C).Rando;
                matrix{3}=num2str(R);
                matrix{4}=num2str(C);
                if ~isempty(track)
                    matrix{5}=num2str(track(i,1));
                    matrix{6}=num2str(track(i,2));
                    matrix{7}=num2str(track(i,3));
                    matrix{8}=num2str(track(i,4));
                    matrix{9}=num2str(track(i,5));
                    matrix{10}=num2str(track(i,6));%We dont need cells outside/inside
                    matrix{11}=num2str(track(i,7));
                    matrix{12}=num2str(track(i,9));
                    matrix{13}=num2str(track(i,10));
                    matrix{14}=num2str(track(i,11));
                else
                    matrix{5}='empty';
                    matrix{6}='empty';
                    matrix{7}='empty';
                    matrix{8}='empty';
                    matrix{9}='empty';
                    matrix{10}='empty';
                    matrix{11}='empty';
                    matrix{12}='empty';
                    matrix{13}='empty';
                    matrix{14}='empty';
                end
                matrixtowrite=sprintf('%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s', matrix{:});
                dlmwrite(cellfile, matrixtowrite,'delimiter', '','-append');
            end
 
        catch newerr
            err=[err; newerr];
            disp(strcat('Row:',num2str(R),'Column',num2str(C)));
            disp(newerr);
            dlmwrite(cellfile, 'Error','delimiter', '','-append');
            dlmwrite(xlsfile, 'Error','delimiter', '','-append');
        end
    end
end
save(list_of_file{FF},'Array');
end
