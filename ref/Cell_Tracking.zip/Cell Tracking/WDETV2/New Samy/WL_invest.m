function [new_list WL] = WL_invest(father)

% ------------------------------------------------------------------------
% function [new_list WL] = WL_invest(father) investigate a folder looking
% for images and then it screens the folder generating names for each
% image and reporting the list of the wave lengthes it found in the folder.
%
%   Output: - new_list: list of images int he folder (array of cells nX1)
%           - WL: list of wave-lengthes (array of cells mX1)
%
%   Input:  - father: folder to investigate (string) 
%
% V. 1.0 - A. Negro, LSCB, EPFL, July 2011
% lscb.epfl.com
% ------------------------------------------------------------------------

% function to investigate name of the file features
cd(father);
% List of file
lista = dir('*.tif*');
%Investigation element by element
new_list = [];
for i = 1 : length(lista)
    % Field number
    IND = strfind(lista(i).name,'F');
    IND_F = IND(1);
    IND = strfind(lista(i).name,'_');
    IND_F = IND_F+1 : 1 : IND(1)-1;
    element.field = str2double(lista(i).name(IND_F));
    % Wave-Length
    IND = strfind(lista(i).name,' ');
    IND_WL = IND(1)+1 : 1 : IND(2)-1;
    element.WL = lista(i).name(IND_WL);
    % Number of well
    IND = strfind(lista(i).name,'s');
    IND_W = IND(1);
    IND = strfind(lista(i).name,'.');
    IND_W = IND_W+1 : 1 : IND(end)-1;
    element.well = str2double(lista(i).name(IND_W));
    % New structure: array of cells
    element.name = lista(i).name;
    new_list = [new_list; element]; %#ok<*AGROW>
end
WL = new_list(1).WL;
for i = 2 : length(new_list)
    WL = [WL;{new_list(i).WL}];
end
WL = unique(WL);
