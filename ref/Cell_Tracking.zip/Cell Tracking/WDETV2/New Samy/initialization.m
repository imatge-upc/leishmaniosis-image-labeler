function [list_of_file, param, fatherDIR, subDIRlist]=initialization()
% ------------------------------------------------------------------------
% initialization asks the user for the parameters (radius of the well), the
% excel combinatorial file, and the input directory containing the videos.
% Then it creates a database saved  as F*.mat in the input directory.
%
%In start: [handles.list_of_file, handles.param, handles.fatherDIR, handles.subDIRlist]=initialization;
%
%   Input: nothing
%
%  Output: -list_of_file: cell array containg the list of files of all the
%          fields.
%          -param: structure containing the parameters of the experiments
%          (radius of the well,etc).
%          -fatherDIR: directory path containing the videos in subfolders.
%          -subDIRlist: cell array containing the list of the subfolders
%          (F1 to F20 eg).
%
% V. 1.0 - F. P�lissier, A. Negro, LSCB, EPFL, December 2011
% lscb.epfl.com
% ------------------------------------------------------------------------
%% Preliminary operation
list_of_file=[];
fatherDIR='';
subDIRlist=[];
% Info about the arrays
prompt = {'Radius of the wells (pixels):','Thickness of the ring shape for wells detection (pixels)','Border around the well (pixel)'};
dlg_title = 'Input: Parameters';
num_lines = 1;
def = {'','5','20'};
answer = inputdlg(prompt,dlg_title,num_lines,def);
r = str2double(answer{1});
rthick = str2double(answer{2});
border = str2double(answer{3});
if isempty(r)
    warning(2,'The radius of the wells is a necessary parameters and cannot be omitted.');
    return;
else
    param.r = r;
    param.rthick = rthick;
    param.border = border;
    param.way = 0;
    param.marg = 40; %To increase the size of the cropped image
end


% Tracking parameters
% Maybe, a better generalization can be found
param.minarea = 200; % To remove false positives
param.maxtravel = 10;
param.cellsize = 8;

% For having a system-indipendent software
sep = '\';
if ismac
    sep = '/';
end
%% Condition LOG reading from Excel Spreadsheet
[PROTCOMB] = protREAD();
if ~isempty(PROTCOMB);
    PCfield = fieldnames(PROTCOMB);
    comando = sprintf('[AR_row, Ar_col] = size(PROTCOMB.%s);',PCfield{1});
    eval(comando);
    % Folder Investigation
    currentDIR = cd;
    fatherDIR = uigetdir(currentDIR,'Select INPUT directory. Fields stored in sub-folders!');
    if fatherDIR ~= 0
        subDIRlist = dirfold(fatherDIR);    % One sub-folder = one condition
        
        %% Database Construction
        % Check if the data in the excel file corresponds to the size of the folder
        if length(PCfield) ==length(subDIRlist)
            cd(fatherDIR);
            
            % Each sub-folder contains the images relative to a certain field
            for FF = 1 : length(subDIRlist)
                FF %#ok<NOPRT>
                clear Array
                % Generation of the list of images to inpuit into the databse
                [new_list WL] = WL_invest(subDIRlist{FF});
                % Screening opf the list
                for II = 1 : length(new_list)
                    II %#ok<NOPRT>
                    % One wavwe-length per-time
                    for JJ = 1 : length(WL)
                        % Ccheck over WL
                        if strcmp(new_list(II).WL,WL{JJ})
                            % Metadata of the image: ID of the well, row and column
                            ID = new_list(II).well;
                            col = mod(ID+1,Ar_col);
                            if col==0
                                col = Ar_col; %#ok<NASGU>
                                row = (ID+1)/Ar_col; %#ok<NASGU>
                            else
                                row = floor((ID+1)/Ar_col)+1; %#ok<NASGU>
                            end
                            % Stack reading and saving
                            nome = strcat(subDIRlist{FF},sep,new_list(II).name);
                            comando = sprintf('Array(row,col).W%02d=''%s'';',JJ,nome);
                            eval(comando);
                            % Wave-length label
                            comando = sprintf('Array(row,col).W%02dID=''%s'';',JJ,WL{JJ});
                            eval(comando);
                            % Protein combination
                            FIELD = subDIRlist{FF};%(indF(end)+1:end);
                            comando = sprintf('Array(row,col).Prot = PROTCOMB.%s(row,col).Prot;',FIELD);
                            eval(comando);
                            comando = sprintf('Array(row,col).Trans = PROTCOMB.%s(row,col).trans;',FIELD);
                            eval(comando);
                            comando = sprintf('Array(row,col).Rando = PROTCOMB.%s(row,col).rando;',FIELD);
                            eval(comando);
                        end
                    end
                end
                cd(fatherDIR);
                save_file = sprintf('%s.mat',subDIRlist{FF});
                save(save_file, 'Array');
                list_of_file = [list_of_file;{save_file}]; %#ok<AGROW>
            end
        end
    end
end
end