Itest = zeros(size(L,1), size(L,2));
Itest = (L==0);
% rgb = imoverlay(I, Itest, [0 1 0]);
In=I;
for j=1:size(I,1)
        for k=1:size(I,2)
            if Itest(j,k) ==1; 
                In(j,k) = max(max(I));
            end
        end
    end
figure, imagesc(In);