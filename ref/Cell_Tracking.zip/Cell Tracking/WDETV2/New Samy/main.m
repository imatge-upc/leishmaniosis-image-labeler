% ------------------------------------------------------------------------
%This is the main part if you dont want to use the GUI (start.m).
%
% The program stores the path, then start the initialization part asking
% for parameters, excel combinatorial file and input directory.
% Then, it creates jobs in parallel and runs the job. Jobs can be monitored
% going to Parallel > Job Monitor.
%
% V. 1.0 - F. P�lissier, A. Negro, LSCB, EPFL, December 2011
% lscb.epfl.com
% ------------------------------------------------------------------------
clear 
clc

% For having a system-independent software
sep = '\';
if ismac
    sep = '/';
end

% questdlg for cell/well analysis

fileDep = uigetdir(cd,'Select Cell Tracking Code Path');
dirDep = {fileDep, strcat(fileDep,sep,'WDETV2'), strcat(fileDep,sep,'WDETV2\EXCEL LOG'),...
    strcat(fileDep,sep,'WDETV2\HSC Specific'), strcat(fileDep,sep,'WDETV2\New Samy'),...
     strcat(fileDep,sep,'WDETV2\Well Detection'),  strcat(fileDep,sep,'LevelSetMethods')};

[list_of_file, param, fatherDIR, subDIRlist]=initialization;
mkdir(strcat(fatherDIR,sep,'results'));

for FF=1:length(list_of_file)
   job(FF)= dfevalasync(@CellTracking, 0, {{FF, list_of_file, param, fatherDIR, subDIRlist}}, 'Configuration', 'local', ...
        'FileDependencies', {fileDep}, 'PathDependencies', dirDep);
% CellTracking(FF, list_of_file,param, fatherDIR, subDIRlist);
end

