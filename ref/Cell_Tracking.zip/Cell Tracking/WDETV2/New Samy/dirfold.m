function thelist = dirfold(father)

% ------------------------------------------------------------------------
% function thelist = dirfold(father) generates the list of subsfolder
% within the input father folder.
%
%   Output: - thelist: list of subfolder (cell array nX1)
%
%   Input:  - father: address of the father folder (string)
%
% V. 1.0 - A. Negro, LSCB, EPFL, July 2011
% lscb.epfl.com
% ------------------------------------------------------------------------

% Investigation of the directory and screen out irrelevant results
thelist = [];
lista = dir(father);
for i = 1 : length(lista)
    if ~strcmp(lista(i).name,'.')
        if ~strcmp(lista(i).name,'..')
            if lista(i).isdir
                thelist = [thelist;{lista(i).name}];
            end
        end
    end
end