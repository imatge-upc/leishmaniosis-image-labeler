function mask_c = mask_correction(mask, stat_mask, dist)
% ------------------------------------------------------------------------
%mask_correction function corrects the mask image removing objects with too low intensity
% or if they are too close from each other.
%In FPtracking: mask_corr = mask_correction(mask, stat_mask, param.cellsize);
%
%   Input: -mask: binary image of the regional maximums of the original
%           image after processing.
%          - stat_mask: statistics if mask obtained with regionprops.
%          - dist: minimal distance between two objects.
%
%  Output: mask_c: binary image with false positive objects removed.
%
% V. 1.0 - F. P�lissier, A. Negro, LSCB, EPFL, December 2011
% lscb.epfl.com
% ------------------------------------------------------------------------
mask_c = mask;
index = [];
for obj=1:length(stat_mask)
    %Look at the object with low intensity.
    if stat_mask(obj).MeanIntensity< 200
        y=stat_mask(obj).PixelList(:,1);
        x =stat_mask(obj).PixelList(:,2);
        mask_c(x,y) = 0;
        %store the index
        index = [index obj]; %#ok<AGROW>
    end
end
if exist('index') %#ok<EXIST>
    stat_mask(index) = [];
end

index=0;
for i=1:length(stat_mask)
    if isempty(find(index == i)) %#ok<EFIND>
        xo = stat_mask(i).Centroid(1);
        yo = stat_mask(i).Centroid(2);
        for j=i+1:length(stat_mask)
            if isempty(find(index == j)) %#ok<EFIND>
                cx = stat_mask(j).Centroid(1);
                cy = stat_mask(j).Centroid(2);
                y=stat_mask(j).PixelList(:,1);
                x =stat_mask(j).PixelList(:,2);
                
                if abs(xo - cx) < dist && abs(yo - cy) < dist && i~=j
                    mask_c(x,y) = 0;
                    index = [index j]; %#ok<AGROW>
                    
                end
            end
        end
    end
end
end