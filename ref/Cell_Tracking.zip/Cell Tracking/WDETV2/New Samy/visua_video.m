figure, 
for i = 1 : 80
    imagesc(BFcorr{i}), colormap gray, axis equal, axis tight
    pause(0.25)
end