function WLID = look4BF(stru)

% ------------------------------------------------------------------------
% function WLID = look4BF(stru) identify in the well structure the ID of
% the wave length corresponding to brightfield for further well
% segmentation.
%
%   Output: - WLID: name of the field containing BF (string)
%
%   Input:  - stru: single well element of the database (stru)
%
% V. 1.0 - A. Negro, LSCB, EPFL, July 2011
% lscb.epfl.com
% ------------------------------------------------------------------------

% Sorting of wave-length
% Fields of the structre
fields = fieldnames(stru);
% Looking for WL general label
match = strfind(fields, 'ID');
% Screen for interesting fields
indOK = [];
for i = 1 : length(match)
    if ~isempty(match{i})
        indOK = [indOK, i]; %#ok<*AGROW>
    end
end
% Screening for idenfying BF fields
WLID = [];
for i = 1 : length(indOK)
    comando = sprintf('varo = stru.%s;',fields{indOK(i)});
    eval(comando);
    BF1 = strfind(varo,'Brightfield');
    BF2 = strfind(varo,'brightfield');
    BF3 = strfind(varo,'BR');
    BF4 = strfind(varo,'BRIGHTFIELD');
    if ~isempty(BF1)|| ~isempty(BF2) || ~isempty(BF3) || ~isempty(BF4)
        indBF = indOK(i);
        indOK(i) = 0;
    end
end
indOK = indOK(indOK~=0);
% Removing ID form the end of the string it's possible to estblish the name
% of the field that contains the video, that's what interest the most
WLID{1} = fields{indBF}(1:end-2);
for i = 1 : length(indOK)
    WLID{i+1} = fields{indOK(i)}(1:end-2);
end