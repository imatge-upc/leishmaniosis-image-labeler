function trackproc = PostProcess(track, Id, deathid, division)
% ------------------------------------------------------------------------
% PostProcess analyzes the divisions and the deaths and look at false
% positives (new daughters which die just soon after).
%
%In FPtracking: tracks2 = PostProcess(tracks2, Idcat, deathid, division);
%
%   Input: -track: matrix containing the track after rounds of tracking and post processing
%          -Id: identification of cells concatenated to add to track as
%   a new column.
%          -deathid: cell array containing the identification of the dead
%        cells. deathid{t} = 2,3 e.g
%          -division: cell array containing the identification of the
%        divisions. E.g if cell number 2 divided in 4 and 5-> division{t} = 2,
%        4,5.
%
%  Output: -trackproc: matrix of track modified
%
% Example:
% You get division{4}= 2,4,5,3,6,7. It means at time 4, cell number 2
% divided in 4 and 5 and cell number 3 divided in 6 and 7.
% You get deathid{6}=5,6. It means cells number 5 and 6 died right after,
% so they are false positives.
% In the code, ind = 3,5 (index of the dead cells in division).
% ind1 contains the daughters to remove. ind1=2,3,5,6.
%In IdFinal we change the ids 4 and 5 in 2 (mother cell) and ids 6 and 7 in
%3 (mother cell).
% ind3 contains the position of the family ind3=1,2,3,4,5,6. We remove this
% family in divisionFinal.
%ind4 contains the index of the dead cells in deathid: ind4 = 1,2. We
%remove these false dead cells in deathFinal.
%Then we change everywhere the false ids 4,5 in 2 and 6,7 in 3.
%ind5 contains the index of the daughters not dead: ind5=2,6 (cells 4 and 7 did
%not die).
%ind6 contains the index of these still alive daughter cells at an other
%time point.
%
% V. 1.0 - F. P�lissier, A. Negro, LSCB, EPFL, December 2011
% lscb.epfl.com
% ------------------------------------------------------------------------

%Id=Idcat;
IdFinal=Id;
divisionFinal = division;
deathFinal = deathid;


for i=1:length(division)
    for j=1:length(deathid)
        %Look inside division and deathid for the indexes which match
        if ~isempty(divisionFinal{i}) && ~isempty(deathFinal{j})
            %ind contains the index in division{i} of the dead cell(s)
            [~, ind]=ismember(deathFinal{j},divisionFinal{i});
            if abs(j-i) < 5 && max(ind)>0 %If the time between division and death is <5 and the indexes match
                %ind1 contains the position of the newborns to remove: if
                %we find 2 and 6, we have to remove 2,3 and 5,6 also
                %(mothers are 1 and 4)
                ind = ind(ind~=0);
                ind1= [3*ceil(ind/3)-1, 3*ceil(ind/3)];
                
                for k=1:length(ind1)
                    ind2=find(divisionFinal{i}(ind1(k))==Id);
                    %Change the index in IdFinal
                    IdFinal(ind2)=divisionFinal{i}(3*ceil(ind1(k)/3)-2); %#ok<FNDSB>
                end
                
                %We store the index to remove the false positives in track
                
                %ind3 contains the position of the family
                ind3 = [3*ceil(ind/3)-2, 3*ceil(ind/3)-1,3*ceil(ind/3)];
                %we remove this false family
                [~, ind4]=ismember(divisionFinal{i}(ind),deathFinal{j});
                divisionFinal{i}(ind3)=[];
                deathFinal{j}(ind4)=[];
                %we have to change in division and death the false newborn id
                %in mother id (eg if cell 17 divided in 18 and 19 we should
                %change 18 or 19 in 17 everywhere)
                ind5 = setxor(ind, ind1);
                for k=1:length(divisionFinal)
                    %Replace in divisionid
                    if ~isempty(division{i}(ind5)) && ~isempty(divisionFinal{k}) && i~=k
                        [~,ind6]=ismember(division{i}(ind5), divisionFinal{k}) ;
                        if max(ind6)>0
                            ind6 = ind6(ind6~=0);
                            [~,ind7]=ismember(divisionFinal{k}(ind6), division{i}) ;
                            divisionFinal{k}(ind6)=division{i}(3*ceil(ind7/3)-2);
                        end
                    end
                    %Replace in deathid
                    if ~isempty(division{i}(ind5)) && ~isempty(deathFinal{k}) && i~=k
                        [~,ind6]=ismember(division{i}(ind5), deathFinal{k}) ;
                        if max(ind6)>0
                            ind6 = ind6(ind6~=0);
                            [~, ind7] = ismember(deathFinal{k}(ind6),division{i});
                            deathFinal{k}(ind6)=division{i}(3*ceil(ind7/3)-2);
                        end
                    end
                end
            end
            
        end
    end
end

trackproc=track;
newId= cell(length(division),1);
for i = 1 : size(track,1)
    index = track(i,3); %Time frame
    newId{index} = [newId{index},IdFinal(i)];
end

%Remove the false positives in tracks: look at the cells which has the same
%id and look at the smallest area-> remove the smallest object between the
%2
index=[]; %#ok<NASGU>
indextoremove=[];
for i= 1: length(newId)
    for j=1:max(newId{i})
        if length(find(j==newId{i})) >1
            ind=find(j==newId{i});
            index=find(i==track(:,3));
            areas=track(index(ind),4);
            ind2=find(max(areas)==areas);
            indextoremove=[indextoremove,index(setxor(ind(ind2),ind))']; %#ok<FNDSB,AGROW>
        end
    end
end
trackproc(indextoremove,:)=[];
end