function varargout = start(varargin)
% ------------------------------------------------------------------------
%START set the matlab path based to the current folder, then open an
%interface with three button: initialization, start and stop.
%The father folder should contain a folder named WDETV2 with the Matlab code, a
%folder named GUI with this start GUI and a folder named LevelSetMethods
%with the Matlab code for the level set method.
%The inititalization button initialize the database using the excel
%combinatorial file and the input directory the user gives.
%The start button creates jobs in parallel. The stop button cancel the
%jobs.
%No input or output. Results are written under two excel files in a folder
%called "results" in the input directory. This folder should be removed
%when the user want to run the program again.
%
% START MATLAB code for start.fig
%      START, by itself, creates a new START or raises the existing
%      singleton*.
%
%      H = START returns the handle to a new START or the handle to
%      the existing singleton*.
%
%      START('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in START.M with the given input arguments.
%
%      START('Property','Value',...) creates a new START or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before start_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to start_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help start

% Last Modified by GUIDE v2.5 14-Dec-2011 13:44:03

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @start_OpeningFcn, ...
                   'gui_OutputFcn',  @start_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before start is made visible.
function start_OpeningFcn(hObject, ~, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to start (see VARARGIN)
set(handles.text1, 'String', 'First, click on initialization button');
if ismac
    handles.sep = '/';
else
    handles.sep = '\';
end

%We need the paths for Matlab function path and parallelization function
%pwd finds the current folder (GUI), and fileparts finds the parent
%directory which contains all the code
handles.PathName=fileparts(pwd);
addpath(genpath(handles.PathName));
handles.fileDep=handles.PathName;
handles.dirDep = {handles.fileDep, strcat(handles.fileDep,handles.sep,'WDETV2'), strcat(handles.fileDep,handles.sep,'WDETV2\EXCEL LOG'),...
     strcat(handles.fileDep,handles.sep,'WDETV2\New Samy'),...
     strcat(handles.fileDep,handles.sep,'WDETV2\Well Detection'),  strcat(handles.fileDep,handles.sep,'LevelSetMethods')};
 set(handles.inibtn, 'Enable', 'on');
set(handles.startbtn, 'Enable', 'off');
set(handles.stopbtn, 'Enable', 'off');
set(hObject,'CloseRequestFcn',@my_closereq)
set(handles.startbtn, 'UserData', 0);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes start wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = start_OutputFcn(~, ~,~) 
% No output in a stand alone code

% --- Executes on button press in inibtn.
function inibtn_Callback(hObject, ~, handles)

set(handles.text1, 'String', 'Initialization...');
[handles.list_of_file, handles.param, handles.fatherDIR, handles.subDIRlist]=initialization;
if isempty(handles.list_of_file)
    set(handles.text1, 'String', 'Your xls file is wrong or your file folder is wrong');
else
mkdir(strcat(handles.fatherDIR,handles.sep,'results'));

% Compute the number of cores in the computer to estimate the time it will
% take
 nc=System.Environment.ProcessorCount/2;
 load(handles.list_of_file{1});
 WLID = look4BF(Array(1,1));
 comando = sprintf('BF = ANtiffread(Array(1,1).%s);',WLID{1});
 eval(comando);
 NumofFrames=length(BF);
 NumofVideos=size(Array,1)*size(Array,2);
 NumofFields=length(handles.list_of_file);
 estimatedTime=(6*NumofFrames*NumofVideos*ceil(NumofFields/nc))/3600;
 
set(handles.text1, 'String', sprintf('Initialization done \n Estimated time = %d hours' ,estimatedTime));
set(hObject,'Enable','off');
set(handles.startbtn, 'Enable', 'on');
set(handles.stopbtn, 'Enable', 'on');
set(handles.startbtn, 'UserData', 0);
end
guidata(hObject, handles);



% --- Executes on button press in startbtn.
function startbtn_Callback(hObject, ~, handles)
% hObject    handle to startbtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.startbtn, 'UserData', 1);
set(handles.startbtn, 'Enable', 'off');
set(handles.stopbtn, 'Enable', 'off');
drawnow
 set(handles.text1, 'String', 'Running...');
 drawnow
 tStart =tic;
 count=1;
for FF=1:length(handles.list_of_file)
   handles.job(count)= dfevalasync(@CellTracking, 0, {{FF, handles.list_of_file, handles.param, handles.fatherDIR, handles.subDIRlist}},...
       'Configuration', 'local', ...
        'FileDependencies', {handles.fileDep}, 'PathDependencies', handles.dirDep);
    count=count+1;
end
set(handles.stopbtn, 'Enable', 'on');
% To have 'stop' button to work correctly
guidata(hObject, handles);

count=0;
while count~=length(handles.job) && get(handles.startbtn,'UserData')==1    
    count=0;
    for i=1:length(handles.job)
        if strcmp(get(handles.job(i), 'State'), 'finished')
            count = count +1;
        end
    end
    set(handles.text1, 'String', strcat('Running... ',num2str(count),'/',num2str(length(handles.job))));
    drawnow
    pause on;
    pause(5);
    pause off;
end

if get(handles.startbtn,'UserData')==1
    telapse = toc(tStart);
    set(handles.text1, 'String', sprintf('Done \n Elapsed time is %g hours', telapse/3600'));
    drawnow
set(handles.startbtn, 'UserData', 0);
end
guidata(hObject, handles);


% --- Executes on button press in stopbtn.
function stopbtn_Callback(hObject, ~, handles)
% hObject    handle to stopbtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% rmdir(strcat(handles.fatherDIR,handles.sep,'results'),'s');
set(handles.text1, 'String', 'Stopped');
set(handles.startbtn, 'Enable', 'off');
set(handles.stopbtn, 'Enable', 'off');
set(handles.inibtn, 'Enable', 'on');
if get(handles.startbtn,'UserData')==1
    cancel(handles.job);
end
set(handles.startbtn, 'UserData', 0);
guidata(hObject, handles);

% --- Executes when user attempts to close figure1.
function my_closereq(hObject, ~,handles)
handles = guidata(hObject);
if get(handles.startbtn,'UserData')==1
    cancel(handles.job);  
end
guidata(hObject, handles) 
 if get(handles.startbtn,'UserData')==0
     delete(hObject);
 end
